/* رابط کاربری مشاور هوشمند روال */
(function () {
  'use strict';

  const engine = window.RevalPlanner;
  const presets = window.RevalPresets;
  const J = window.RevalJalali;   // تقویم شمسی
  const api = window.revalPlanner || null;

  const WEEKDAY_FA = engine.WEEKDAY_FA;
  const WEEKDAY_KEY = engine.WEEKDAY_KEY;
  const KIND_CLASS = {
    learn: 'b-learn', review: 'b-review', practice: 'b-practice',
    mock: 'b-mock', analysis: 'b-analysis', warmup: 'b-warmup',
    reteach: 'b-reteach', boost: 'b-boost', cumreview: 'b-cum', classfix: 'b-classfix',
    finalprep: 'b-final', deadlinecheck: 'b-deadline', carry: 'b-carry', carryreview: 'b-carry',
  };

  const WEEKDAYS_FA = ['شنبه', 'یکشنبه', 'دوشنبه', 'سه‌شنبه', 'چهارشنبه', 'پنجشنبه', 'جمعه'];

  const DL_STATUS = {
    met: { fa: 'سر وقت تمام شد', cls: 'ok' },
    ontrack: { fa: 'روی مسیر', cls: 'ok' },
    late: { fa: 'دیر می‌شود', cls: 'bad' },
    'late-done': { fa: 'با تأخیر تمام شد', cls: 'warn' },
  };

  const $ = (id) => document.getElementById(id);
  const pad = (n) => String(n).padStart(2, '0');
  const iso = (d) => d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());

  let state = {
    config: null,
    plan: null,
    week: 0,
    selectedDay: null,
    scores: {},
    done: {},
    general: null,
    gradeSel: ['دوازدهم'],   // پایه‌های انتخابی برای دروس عمومی
    generalEdits: {},        // ویرایش‌های کاربر روی هر درس عمومی (با id)
    chapters: {},            // ارزیابی فصل‌به‌فصل: sid → [{name, read, mastery}]
    coreSubjects: [],        // آخرین فهرست دروس اختصاصی نمایش‌داده‌شده
    assessOpen: {},          // کدام درس‌ها در بخش ارزیابی باز است
    finals: {},              // سوابق: id → {current, target, inProgram, influence}
    deadlineBooks: [],       // مهلت‌های کتابی (مدل اول)
    deadlineExams: [],       // مهلت‌های کوتاه: تک‌درس/جامع (مدل دوم)
    offDates: [],            // روزهای خارج از برنامه
    visited: {},             // قدم‌هایی که کاربر باز کرده (تیک مسیر آماده‌سازی)
    startTimes: null,        // ساعت شروع هر روز
    timeMode: 'fixed',       // دستی یا خودکار (فقط سقف)
    lastCarry: [],           // کارهای جامانده‌ای که بازچینش شدند
  };

  /* ---------------- ابزار ---------------- */

  function toast(msg) {
    const el = $('toast');
    el.textContent = msg;
    el.classList.add('show');
    clearTimeout(toast._t);
    toast._t = setTimeout(() => el.classList.remove('show'), 2600);
  }

  const EN_DIGITS = { '۰': '0', '۱': '1', '۲': '2', '۳': '3', '۴': '4', '۵': '5', '۶': '6', '۷': '7', '۸': '8', '۹': '9', '٠': '0', '١': '1', '٢': '2', '٣': '3', '٤': '4', '٥': '5', '٦': '6', '٧': '7', '٨': '8', '٩': '9', '٫': '.', ',': '.' };
  function numVal(el) {
    if (!el) return 0;
    const raw = String(el.value == null ? '' : el.value).replace(/[۰-۹٠-٩٫,]/g, (c) => EN_DIGITS[c] || c);
    const n = parseFloat(raw);
    return isFinite(n) ? n : 0;
  }
  function faDigits(v) {
    return String(v == null ? '' : v).replace(/\d/g, (d) => '۰۱۲۳۴۵۶۷۸۹'[d]).replace(/\./g, '٫');
  }

  /* ---------- ساعت: همیشه ۲۴ ساعته، با رقم فارسی ----------
     ورودی <input type="time"> به زبان ویندوز وابسته است و در فارسی
     «04:00 PM» نشان می‌دهد؛ پس ورودی متنیِ خودمان را داریم. */
  function normTime(raw) {
    let v = String(raw == null ? '' : raw).trim()
      .replace(/[۰-۹٠-٩]/g, (c) => EN_DIGITS[c] || c)
      .replace(/\s+/g, '')
      .replace(/[٫،.]/g, ':')
      .replace(/[^\d:]/g, '');
    if (!v) return '';
    if (v.indexOf(':') === -1) {
      if (v.length === 1 || v.length === 2) v += ':00';
      else if (v.length === 3) v = '0' + v[0] + ':' + v.slice(1);
      else if (v.length === 4) v = v.slice(0, 2) + ':' + v.slice(2);
      else return '';
    }
    const m = v.match(/^(\d{1,2}):(\d{1,2})$/);
    if (!m) return '';
    let h = Number(m[1]);
    let mi = Number(m[2]);
    if (h === 24 && mi === 0) return '24:00';
    if (!(h >= 0 && h <= 23) || !(mi >= 0 && mi <= 59)) return '';
    return String(h).padStart(2, '0') + ':' + String(mi).padStart(2, '0');
  }
  function timeFa(v) {
    const t = normTime(v);
    return t ? faDigits(t) : (v ? faDigits(String(v)) : '');
  }
  function readTime(el, fallback) {
    if (!el) return fallback;
    const t = normTime(el.value);
    if (!t) {
      el.classList.add('bad');
      el.title = 'ساعت را به شکل ۲۴ ساعته بنویس، مثلاً ۱۶:۳۰ یا ۰۰:۳۰';
      return fallback;
    }
    el.classList.remove('bad');
    return t;
  }
  /** رشتهٔ HTML یک ورودی ساعت (متنی، ۲۴ ساعته) */
  function timeInput(attr, value, def) {
    return '<input class="tin" ' + attr + ' value="' + timeFa(value || def || '') + '" ' +
      'placeholder="' + timeFa(def || '00:00') + '" inputmode="numeric" autocomplete="off" />';
  }

  function faNum(n) {
    // گرد کردن به یک رقم اعشار تا اعداد اعشاریِ شناور (مثل ۲۷٫۳۴۹۹۹۹) نمایش داده نشوند
    const num = Number(n);
    const val = isFinite(num) ? Math.round(num * 10) / 10 : n;
    return String(val)
      .replace(/\./g, '٫')
      .replace(/\d/g, (d) => '۰۱۲۳۴۵۶۷۸۹'[d]);
  }

  /* جداسازی جهت‌نویسی برای بازه‌های زمانی/تاریخ در متن راست‌به‌چپ */
  function bidi(txt) {
    return '<span dir="ltr" style="unicode-bidi:isolate">' + String(txt) + '</span>';
  }

  /* ---------------- تاریخ شمسی ---------------- */

  /** رشتهٔ شمسیِ فیلد تاریخ را به ISO میلادی تبدیل می‌کند (برای ذخیرهٔ داخلی) */
  function readJDate(id) {
    const el = $(id);
    if (!el) return null;
    if (el.dataset.iso) return el.dataset.iso;
    const parsed = J ? J.parse(el.value) : null;
    return parsed;
  }

  function writeJDate(id, iso) {
    const el = $(id);
    if (!el) return;
    el.dataset.iso = iso || '';
    el.value = iso && J ? J.fmt(iso) : '';
    if (J) J.attachPicker(el);
  }

  /** «۷ آبان» برای قرص‌های روز هفته */
  function jDayMonth(iso) {
    if (!J) return '';
    const j = J.fromISO(iso);
    return j ? faNum(j.jd) + ' ' + J.MONTHS[j.jm - 1] : '';
  }

  /** نمایش شمسی یک تاریخ ISO (بدون نام روز — روز هفته در بالای همان کارت) */
  function jDateFull(iso) {
    return J ? J.fmt(iso) : faNum(iso);
  }

  function weekOf(plan, dayIndex) {
    return Math.floor(dayIndex / 7);
  }

  /* ---------------- ساعت شروع هر روز ---------------- */

  const DEFAULT_START_TIMES = {
    sat: '16:00', sun: '16:00', mon: '16:00', tue: '16:00', wed: '16:00', thu: '09:00', fri: '09:00',
  };

  function renderStartTimes(values) {
    const box = $('startTimes');
    if (!box) return;
    const v = Object.assign({}, DEFAULT_START_TIMES, values || {});
    box.innerHTML = WEEKDAY_FA.map((w, i) =>
      '<div><label>' + w + '</label>' + timeInput('data-start="' + WEEKDAY_KEY[i] + '"', v[WEEKDAY_KEY[i]], '16:00') + '</div>').join('');
  }

  function readStartTimes() {
    const out = {};
    document.querySelectorAll('[data-start]').forEach((inp) => { out[inp.dataset.start] = readTime(inp, '16:00'); });
    return Object.keys(out).length ? out : Object.assign({}, DEFAULT_START_TIMES);
  }

  /* ---------------- روزهای خارج از برنامه ---------------- */

  function renderOffRows(rows) {
    const box = $('offRows');
    if (!box) return;
    box.innerHTML = '';
    (rows || []).forEach((o) => {
      const div = document.createElement('div');
      div.className = 'dyn-row off';
      div.innerHTML =
        '<div><label>تاریخ (شمسی)</label><input data-of="date" data-jdate data-iso="' + esc(o.date || '') + '" /></div>' +
        '<div><label>نوع</label><select data-of="kind">' +
          '<option value="halt"' + (o.kind !== 'light' ? ' selected' : '') + '>تعطیل کامل</option>' +
          '<option value="light"' + (o.kind === 'light' ? ' selected' : '') + '>روز سبک</option>' +
        '</select></div>' +
        '<div><label>یادداشت</label><input data-of="note" value="' + esc(o.note || '') + '" placeholder="سفر / بیماری / مهمانی" /></div>' +
        '<button class="del" title="حذف">✕</button>';
      div.querySelector('.del').addEventListener('click', () => div.remove());
      box.appendChild(div);
    });
    if (!box.children.length) box.innerHTML = '<div class="muted" style="font-size:11.5px">روزی ثبت نشده — همهٔ روزها عادی‌اند.</div>';
    else if (J) J.attachAll(box);
  }

  function readOffRows() {
    const out = [];
    $('offRows').querySelectorAll('.dyn-row').forEach((row) => {
      const d = row.querySelector('[data-of="date"]');
      const date = d.dataset.iso || (J ? J.parse(d.value) : null);
      if (!date) return;
      out.push({
        date,
        kind: row.querySelector('[data-of="kind"]').value,
        note: row.querySelector('[data-of="note"]').value.trim(),
      });
    });
    return out;
  }

  $('addOff').addEventListener('click', () => {
    const rows = readOffRows();
    const d = new Date(); d.setDate(d.getDate() + 3);
    rows.push({ date: J ? J.dateToISO(d) : iso(d), kind: 'halt', note: '' });
    renderOffRows(rows);
  });

  /* ---------------- مدل ۱: مهلت کتابی ---------------- */

  function coreSubjectOptions(selected) {
    const list = state.coreSubjects && state.coreSubjects.length ? state.coreSubjects : presets.subjectsFor($('field').value || 'tajrobi');
    return list.map((x) => '<option value="' + esc(x.id) + '"' + (x.id === selected ? ' selected' : '') + '>' + esc(x.name) + '</option>').join('');
  }

  function renderBookDeadlineRows(rows) {
    const box = $('bookDeadlineRows');
    if (!box) return;
    box.innerHTML = '';
    (rows || []).forEach((r) => {
      const div = document.createElement('div');
      div.className = 'dyn-row dlbook';
      div.innerHTML =
        '<div><label>کتاب</label><select data-bd="subjectId">' + coreSubjectOptions(r.subjectId) + '</select></div>' +
        '<div><label>تا تاریخ (شمسی)</label><input data-bd="date" data-jdate data-iso="' + esc(r.date || '') + '" /></div>' +
        '<div><label>هدف</label><select data-bd="goal">' +
          '<option value="read"' + (r.goal !== 'solid' ? ' selected' : '') + '>خوانده + تثبیت شود</option>' +
          '<option value="solid"' + (r.goal === 'solid' ? ' selected' : '') + '>تسلط کامل (فقط مرور بماند)</option>' +
        '</select></div>' +
        '<button class="del" title="حذف">✕</button>';
      div.querySelector('.del').addEventListener('click', () => div.remove());
      box.appendChild(div);
    });
    const cnt = $('bookDeadlineCount');
    if (cnt) cnt.textContent = faNum(box.children.length);
    if (!box.children.length) box.innerHTML = '<div class="muted" style="font-size:11.5px">مهلت کتابی ثبت نشده — برنامه فقط بر پایهٔ کنکور چیده می‌شود.</div>';
    else if (J) J.attachAll(box);
  }

  function readBookDeadlines() {
    const out = [];
    $('bookDeadlineRows').querySelectorAll('.dyn-row').forEach((row) => {
      const d = row.querySelector('[data-bd="date"]');
      const date = d.dataset.iso || (J ? J.parse(d.value) : null);
      if (!date) return;
      out.push({
        subjectId: row.querySelector('[data-bd="subjectId"]').value,
        date,
        goal: row.querySelector('[data-bd="goal"]').value,
      });
    });
    return out;
  }

  $('addBookDeadline').addEventListener('click', () => {
    const rows = readBookDeadlines();
    const d = new Date(); d.setMonth(d.getMonth() + 4);
    rows.push({ subjectId: (state.coreSubjects[0] || {}).id || 'bio', date: J ? J.dateToISO(d) : iso(d), goal: 'read' });
    renderBookDeadlineRows(rows);
  });

  $('suggestBookDeadlines').addEventListener('click', () => {
    state.deadlineBooks = presets.suggestedBookDeadlines
      ? presets.suggestedBookDeadlines(state.coreSubjects && state.coreSubjects.length ? state.coreSubjects : presets.subjectsFor($('field').value || 'tajrobi'))
      : [];
    renderBookDeadlineRows(state.deadlineBooks);
    toast('مهلت پیشنهادی ساخته شد — هر تاریخ را می‌توانی عوض کنی.');
  });

  /* ---------------- آزمون‌های دوره‌ای (هر روز هفته، هر N هفته) ---------------- */

  function subjectOptionsAll(selected) {
    const list = (state.coreSubjects && state.coreSubjects.length ? state.coreSubjects : presets.subjectsFor($('field').value || 'tajrobi'));
    return list.map((s) => '<option value="' + s.id + '"' +
      ((selected || []).indexOf(s.id) !== -1 ? ' selected' : '') + '>' + esc(s.name) + '</option>').join('');
  }

  function renderMockRows(rows) {
    const box = $('mockRows');
    if (!box) return;
    box.innerHTML = '';
    (rows || []).forEach((m) => {
      const div = document.createElement('div');
      div.className = 'dyn-row mock';
      div.innerHTML =
        '<div><label>عنوان آزمون</label><input data-mk="title" value="' + esc(m.title || '') + '" placeholder="زیستاز / آلفا / قلم‌چی" /></div>' +
        '<div><label>روز هفته</label><select data-mk="day">' +
          WEEKDAYS_FA.map((d, i) => '<option value="' + i + '"' + (Number(m.day) === i ? ' selected' : '') + '>' + d + '</option>').join('') +
        '</select></div>' +
        '<div><label>تکرار</label><select data-mk="everyNWeeks">' +
          [[1, 'هر هفته'], [2, 'هر ۲ هفته'], [3, 'هر ۳ هفته'], [4, 'هر ۴ هفته']]
            .map(([v, t]) => '<option value="' + v + '"' + (Number(m.everyNWeeks || 1) === v ? ' selected' : '') + '>' + t + '</option>').join('') +
        '</select></div>' +
        '<div><label>ساعت شروع (اختیاری)</label>' + timeInput('data-mk="start"', m.start || '', '۰۹:۰۰') + '</div>' +
        '<div><label>مدت (دقیقه)</label><select data-mk="minutes">' +
          [60, 90, 100, 120, 150, 180, 210]
            .map((v) => '<option value="' + v + '"' + (Number(m.minutes || 100) === v ? ' selected' : '') + '>' + faNum(v) + '</option>').join('') +
        '</select></div>' +
        '<div class="mock-subjects"><label>دروس (خالی = همه)</label><select data-mk="subjectIds" multiple size="4">' + subjectOptionsAll(m.subjectIds) + '</select></div>' +
        '<button class="del mock-del" title="حذف">✕</button>';
      div.querySelector('.del').addEventListener('click', () => div.remove());
      box.appendChild(div);
    });
    if (!box.children.length) {
      box.innerHTML = '<div class="muted" style="font-size:11.5px">آزمون دوره‌ای ثبت نشده — یک آزمون جامع هفتگی ساده چیده می‌شود.</div>';
    }
  }

  function readMocks() {
    const out = [];
    const box = $('mockRows');
    if (!box) return out;
    box.querySelectorAll('.dyn-row').forEach((row) => {
      const title = (row.querySelector('[data-mk="title"]').value || '').trim();
      const day = Number(row.querySelector('[data-mk="day"]').value);
      const every = Number(row.querySelector('[data-mk="everyNWeeks"]').value) || 1;
      const start = normTime(row.querySelector('[data-mk="start"]').value) || null;
      const minutes = Number(row.querySelector('[data-mk="minutes"]').value) || 100;
      const subjectIds = Array.from(row.querySelector('[data-mk="subjectIds"]').selectedOptions).map((o) => o.value);
      if (!title && !subjectIds.length) return;
      out.push({ title: title || 'آزمون دوره‌ای', day, everyNWeeks: every, start, minutes, subjectIds });
    });
    return out;
  }

  $('addMock') && $('addMock').addEventListener('click', () => {
    state.weeklyMocks = readMocks().concat([{
      title: 'آزمون دوره‌ای', day: 5, everyNWeeks: 1, minutes: 100, subjectIds: [],
    }]);
    renderMockRows(state.weeklyMocks);
  });

  $('suggestMocks') && $('suggestMocks').addEventListener('click', () => {
    /* پیشنهاد حرفه‌ای: آزمون آزمایشی هر ۲ هفته + آزمون تک‌درس هفتگی */
    state.weeklyMocks = [
      { title: 'آزمون جامع آزمایشی', day: 5, everyNWeeks: 2, minutes: 180, subjectIds: [] },
      { title: 'آزمون تک‌درس هفته', day: 5, everyNWeeks: 2, minutes: 100, subjectIds: [] },
    ];
    renderMockRows(state.weeklyMocks);
    toast('دو آزمون دوره‌ای پیشنهاد شد (پنجشنبه‌ها، یکی‌درمیان).');
  });

  $('examDatePreset') && $('examDatePreset').addEventListener('change', (e) => {
    const v = e.target.value;
    if (!v) return;
    const inp = $('examDate');
    const d = new Date(v + 'T00:00:00');
    inp.value = J ? J.fmt(v) : v;
    inp.dataset.iso = v;
    if (J && J.setIso) J.setIso(inp, v);
    toast('تاریخ آزمون هدف: ' + (J ? J.fmt(v) : v));
    e.target.value = '';
  });

  /* ---------------- مدل ۲: آزمون تک‌درس / جامع ---------------- */

  function renderShortDeadlineRows(rows) {
    const box = $('shortDeadlineRows');
    if (!box) return;
    box.innerHTML = '';
    const cnt = $('shortDeadlineCount');
    if (cnt) cnt.textContent = faNum((rows || []).length);
    (rows || []).forEach((r) => {
      const isSingle = r.kind !== 'comprehensive';
      const sub = state.coreSubjects.find((x) => x.id === r.subjectId) || state.coreSubjects[0] || { chapters: 24 };
      const chapters = sub.chapters || 24;
      const fromOpts = Array.from({ length: chapters }, (_, i) => i + 1)
        .map((n) => '<option value="' + n + '"' + ((r.from || 1) === n ? ' selected' : '') + '>' + faNum(n) + '</option>').join('');
      const toOpts = Array.from({ length: chapters }, (_, i) => i + 1)
        .map((n) => '<option value="' + n + '"' + ((r.to || chapters) === n ? ' selected' : '') + '>' + faNum(n) + '</option>').join('');
      const div = document.createElement('div');
      div.className = 'dyn-row dlexam';
      div.innerHTML =
        '<div><label>عنوان</label><input data-sd="title" value="' + esc(r.title || '') + '" placeholder="آزمون فصل ۲ زیست" /></div>' +
        '<div><label>نوع</label><select data-sd="kind">' +
          '<option value="single"' + (isSingle ? ' selected' : '') + '>تک‌درس</option>' +
          '<option value="comprehensive"' + (!isSingle ? ' selected' : '') + '>جامع</option>' +
        '</select></div>' +
        '<div><label>درس</label><select data-sd="subjectId">' + coreSubjectOptions(r.subjectId) + '</select></div>' +
        '<div><label>از فصل</label><select data-sd="from">' + fromOpts + '</select></div>' +
        '<div><label>تا فصل</label><select data-sd="to">' + toOpts + '</select></div>' +
        '<div><label>تاریخ (شمسی)</label><input data-sd="date" data-jdate data-iso="' + esc(r.date || '') + '" /></div>' +
        '<button class="del" title="حذف">✕</button>';
      div.querySelector('.del').addEventListener('click', () => div.remove());
      box.appendChild(div);
    });
    if (!box.children.length) box.innerHTML = '<div class="muted" style="font-size:11.5px">آزمونی ثبت نشده.</div>';
    else if (J) J.attachAll(box);
  }

  function readShortDeadlines() {
    const out = [];
    $('shortDeadlineRows').querySelectorAll('.dyn-row').forEach((row) => {
      const get = (f) => row.querySelector('[data-sd="' + f + '"]');
      const d = get('date');
      const date = d.dataset.iso || (J ? J.parse(d.value) : null);
      if (!date) return;
      const kind = get('kind').value === 'comprehensive' ? 'comprehensive' : 'single';
      out.push({
        title: get('title').value.trim() || (kind === 'single' ? 'آزمون تک‌درس' : 'آزمون جامع'),
        kind,
        subjectId: kind === 'single' ? get('subjectId').value : null,
        from: Number(get('from').value) || 1,
        to: Number(get('to').value) || 120,
        date,
      });
    });
    return out;
  }

  $('addShortDeadline').addEventListener('click', () => {
    const rows = readShortDeadlines();
    const d = new Date(); d.setDate(d.getDate() + 21);
    rows.push({
      title: '', kind: 'single', subjectId: (state.coreSubjects[0] || {}).id || 'bio',
      from: 1, to: 1, date: J ? J.dateToISO(d) : iso(d),
    });
    renderShortDeadlineRows(rows);
  });

  /* ---------------- سوابق تحصیلی ---------------- */

  function finalsDefaults(field, grade) {
    return presets.finalsFor ? presets.finalsFor(field || 'tajrobi', grade || 'دوازدهم') : [];
  }

  function renderFinalsTable() {
    const box = $('finalsTable');
    if (!box) return;
    const courses = state.finalsList || [];
    if (!courses.length) { box.innerHTML = '<tr><td class="muted">درسی بارگذاری نشده.</td></tr>'; return; }
    box.innerHTML =
      '<thead><tr><th>درس</th><th>ضریب</th><th>نمرهٔ فعلی (۰–۲۰)</th><th>هدف</th><th>در برنامه</th></tr></thead><tbody>' +
      courses.map((c, i) => {
        const st = state.finals[c.id] || {};
        const cur = st.current == null ? '' : st.current;
        return '<tr data-fin-id="' + esc(c.id) + '">' +
          '<td><b>' + esc(c.name) + '</b></td>' +
          '<td>' + faNum(c.influence) + '</td>' +
          '<td><input data-fin-cur="' + i + '" value="' + (cur === '' ? '' : faNum(cur)) + '" placeholder="۱۲ (فرض)" style="max-width:90px" /></td>' +
          '<td><input data-fin-tgt="' + i + '" value="' + faNum(st.target == null ? c.target : st.target) + '" style="max-width:70px" /></td>' +
          '<td><input type="checkbox" data-fin-in="' + i + '"' + (st.inProgram === false ? '' : ' checked') + ' /></td>' +
        '</tr>';
      }).join('') + '</tbody>';

    box.querySelectorAll('[data-fin-cur]').forEach((inp) => {
      inp.addEventListener('input', () => {
        const c = state.finalsList[Number(inp.dataset.finCur || inp.getAttribute('data-fin-cur'))];
        if (!c) return;
        state.finals[c.id] = state.finals[c.id] || {};
        state.finals[c.id].current = inp.value.trim() === '' ? null : faToEn(inp.value);
      });
    });
    box.querySelectorAll('[data-fin-tgt]').forEach((inp) => {
      inp.addEventListener('input', () => {
        const c = state.finalsList[Number(inp.getAttribute('data-fin-tgt'))];
        if (!c) return;
        state.finals[c.id] = state.finals[c.id] || {};
        state.finals[c.id].target = faToEn(inp.value);
      });
    });
    box.querySelectorAll('[data-fin-in]').forEach((inp) => {
      inp.addEventListener('change', () => {
        const c = state.finalsList[Number(inp.getAttribute('data-fin-in'))];
        if (!c) return;
        state.finals[c.id] = state.finals[c.id] || {};
        state.finals[c.id].inProgram = inp.checked;
      });
    });
  }

  function readFinals() {
    return (state.finalsList || []).map((c) => {
      const st = state.finals[c.id] || {};
      const cur = st.current;
      return {
        id: c.id, name: c.name, grade: c.grade, influence: c.influence,
        current: cur === '' || cur == null ? null : Number(faToEn(String(cur))),
        target: st.target == null || st.target === '' ? c.target : Number(faToEn(String(st.target))),
        inProgram: st.inProgram !== false,
      };
    });
  }

  function loadFinalsFor(grade) {
    const list = finalsDefaults($('field').value, grade);
    state.finalsList = list;
    list.forEach((c) => {
      if (!state.finals[c.id]) state.finals[c.id] = { current: null, target: c.target, inProgram: true };
    });
    renderFinalsTable();
  }

  $('finalsGrade').addEventListener('change', () => {
    loadFinalsFor($('finalsGrade').value);
    toast('درس‌های نهایی پایهٔ ' + $('finalsGrade').value + ' بارگذاری شد.');
  });

  $('finalsDefaults').addEventListener('click', () => {
    state.finals = {};
    loadFinalsFor($('finalsGrade').value);
    toast('درس‌های نهایی و نمره‌ها بازگردانی شد.');
  });

  /* ---------------- ناوبری (نوار کنار) ---------------- */

  const NAVS = () => Array.from(document.querySelectorAll('.nav[data-view]'));

  function gotoView(name) {
    const nav = NAVS().find((n) => n.dataset.view === name);
    if (!nav) return;
    NAVS().forEach((t) => t.classList.remove('active'));
    document.querySelectorAll('.view').forEach((v) => v.classList.remove('active'));
    nav.classList.add('active');
    const view = $('view-' + name);
    if (view) view.classList.add('active');
    const scroller = $('mainScroll');
    if (scroller) scroller.scrollTop = 0;
    document.querySelector('aside') && document.querySelector('aside').classList.remove('open');
    if (name === 'report') renderReport();
    if (String(name).indexOf('step-') === 0) {
      state.visited = state.visited || {};
      state.visited[name] = true;
      try { persist(); } catch (e) { /* بی‌صدا */ }
      renderHome();
    }
    if (name === 'home') renderHome();
    try { window.__revalView = name; } catch (e) { /* بی‌صدا */ }
  }

  NAVS().forEach((nav) => nav.addEventListener('click', () => gotoView(nav.dataset.view)));
  /* سازگاری با نسخهٔ قبل (کلاس .tab) */
  document.querySelectorAll('.tab[data-view]').forEach((tab) => {
    tab.addEventListener('click', () => gotoView(tab.dataset.view));
  });

  /* ---------------- خانه: نمای کلی ---------------- */

  function readAvailabilityTotal() {
    let total = 0;
    document.querySelectorAll('[data-avail]').forEach((el) => { total += Math.max(0, numVal(el)); });
    return total;
  }
  function readChaptersRead() {
    let read = 0, all = 0;
    document.querySelectorAll('[data-cf="read"]').forEach((el) => { all += 1; if (el.checked) read += 1; });
    return { read, all };
  }
  function readMocksCount() {
    return document.querySelectorAll('#mockRows .dyn-row').length;
  }
  function readDeadlinesCount() {
    return document.querySelectorAll('#bookDeadlineRows .dyn-row, #shortDeadlineRows .dyn-row').length;
  }
  function readFinalsCount() {
    return document.querySelectorAll('#finalsTable [data-fin-cur]').length;
  }

  const STEPS_META = [
    { n: 1, view: 'step-1', title: 'دربارهٔ تو', hint: 'پایه، رشته، تاریخ کنکور' },
    { n: 2, view: 'step-2', title: 'زمان‌های تو', hint: 'ساعت مطالعه و شروع' },
    { n: 3, view: 'step-3', title: 'کلاس‌ها و رویدادها', hint: 'کلاس، آزمون، سفر', optional: true },
    { n: 4, view: 'step-4', title: 'دروس و تسلط', hint: 'ارزیابی فصل‌به‌فصل' },
    { n: 5, view: 'step-5', title: 'سوابق تحصیلی', hint: 'نمرات نهایی' },
    { n: 6, view: 'step-6', title: 'مهلت‌ها و آزمون‌ها', hint: 'اختیاری — برنامه پیش‌فرض هم خوب است', optional: true },
  ];

  function stepValid() {
    const avail = readAvailabilityTotal();
    const ch = readChaptersRead();
    const finalsOn = $('finalsEnabled') ? $('finalsEnabled').value === '1' : false;
    const nameOk = Boolean(($('name') && $('name').value.trim()) || ($('grade') && $('grade').value));
    return {
      1: Boolean(nameOk),
      2: avail > 0,
      3: document.querySelectorAll('#classRows .dyn-row, #examRows .dyn-row, #offRows .dyn-row').length > 0,
      4: ch.read > 0,
      5: finalsOn && readFinalsCount() > 0,
      6: readMocksCount() > 0 || readDeadlinesCount() > 0,
    };
  }

  /* یک قدم «تکمیل‌شده» است که هم کاربر بازش کرده باشد و هم داده‌اش معتبر باشد */
  function stepStatus() {
    const valid = stepValid();
    const out = {};
    [1, 2, 3, 4, 5, 6].forEach((n) => {
      const seen = state.visited && state.visited['step-' + n];
      out[n] = Boolean(seen && valid[n]);
    });
    return out;
  }

  function renderHome() {
    const st = stepStatus();
    const avail = readAvailabilityTotal();
    const ch = readChaptersRead();

    /* چیپ تیک روی نوار کنار */
    NAVS().forEach((nav) => {
      const step = Number(nav.dataset.step || 0);
      if (!step) return;
      const tick = nav.querySelector('.tick');
      const num = nav.querySelector('.num');
      const meta = STEPS_META.find((m) => m.n === step);
      const done = Boolean(st[step]);
      if (tick) tick.hidden = !done;
      if (num) {
        num.classList.toggle('done', done);
        num.classList.toggle('opt', !done && Boolean(meta && meta.optional));
      }
    });

    /* چک‌لیست خانه */
    const box = $('homeSteps');
    if (box) {
      const doneCount = STEPS_META.filter((m) => st[m.n]).length;
      const tag = $('homeProgressTag');
      if (tag) tag.textContent = faNum(doneCount) + ' از ۶';
      box.innerHTML = STEPS_META.map((m) => {
        const done = Boolean(st[m.n]);
        const cls = 'chkitem' + (done ? ' done' : (m.optional ? ' opt' : ''));
        return '<button class="' + cls + '" data-goto="' + m.view + '">' +
          '<span class="ic">' + (done ? '✓' : faNum(m.n)) + '</span>' +
          '<span class="tx"><b>' + m.title + '</b><small>' + (done ? 'تکمیل شد' : m.hint) + '</small></span>' +
          '<span class="go">' + (done ? 'ویرایش' : 'برو') + ' <span class="ar">‹</span></span></button>';
      }).join('');
      box.querySelectorAll('[data-goto]').forEach((b) => b.addEventListener('click', () => gotoView(b.dataset.goto)));
    }

    /* KPIهای خانه */
    const kpis = $('homeKpis');
    if (kpis) {
      let daysLeft = 0;
      try {
        const cfgStart = $('startDate') && $('startDate').dataset.iso;
        const cfgExam = $('examDate') && $('examDate').dataset.iso;
        if (cfgStart && cfgExam) daysLeft = Math.max(0, Math.round((new Date(cfgExam) - new Date(cfgStart)) / 86400000));
      } catch (e) { /* بی‌صدا */ }
      const items = [
        { v: faNum(avail) + ' ساعت', l: 'جمع ساعت هفتگی' },
        { v: faNum(daysLeft) + ' روز', l: 'تا آزمون هدف' },
        { v: faNum(ch.read) + ' از ' + faNum(ch.all), l: 'فصل خوانده‌شده' },
        { v: faNum(readFinalsCount()), l: 'درس سوابق' },
      ];
      kpis.innerHTML = items.map((i) => '<div class="stat"><b>' + i.v + '</b><span>' + i.l + '</span></div>').join('');
    }

    /* وضعیت برنامه */
    const lead = $('homePlanLead');
    const stats = $('homePlanStats');
    if (lead && stats) {
      if (state.plan && state.plan.summary) {
        const sm = state.plan.summary;
        const cov = sm.coverage || {};
        const firstDay = state.plan.days[0] ? state.plan.days[0].date : '';
        const lastDay = state.plan.days[state.plan.days.length - 1] ? state.plan.days[state.plan.days.length - 1].date : '';
        const fmt = (iso) => (iso && J && J.fmt) ? J.fmt(iso) : (iso || '');
        lead.textContent = 'برنامهٔ فعلی ساخته شده است — ' + faNum(state.plan.days.length) + ' روز، از ' +
          fmt(firstDay) + ' تا ' + fmt(lastDay) + '.';
        stats.innerHTML = [
          { v: faNum(Math.round(cov.coverageRatio || 0)) + '٪', l: 'پوشش فصل‌ها' },
          { v: faNum(cov.testsPlanned || 0), l: 'تست چیده‌شده' },
          { v: faNum(Math.round((sm.totalMinutes || 0) / 60)) + ' ساعت', l: 'زمان کل' },
        ].map((i) => '<div class="stat"><b>' + i.v + '</b><span>' + i.l + '</span></div>').join('');
      } else {
        stats.innerHTML = '';
      }
    }

    /* کارت‌های خطا در خانه + برنامهٔ امروز و روزهای آینده */
    try { renderIssues(issuesOf(state.plan), $('homeIssues')); } catch (e) { /* بی‌صدا */ }
    try { renderHomeToday(); } catch (e) { /* بی‌صدا */ }
  }

  /* ══════════════════════════════════════════════════════════════════
     خانه: برنامهٔ امروز + روزهای آینده (با تاریخ شمسی و ساعت مطالعه)
     ══════════════════════════════════════════════════════════════════ */
  function dayMinutes(d) {
    if (!d) return 0;
    if (d.plannedMinutes) return d.plannedMinutes;
    return (d.blocks || []).reduce((a, b) => a + Math.max(0, (b.end || 0) - (b.start || 0)), 0);
  }
  function dayTests(d) {
    return (d.blocks || []).reduce((a, b) => a + (b.practiceCount || 0), 0);
  }
  function hoursFa(mins) {
    const h = Math.round((mins / 60) * 10) / 10;
    return faNum(h);
  }

  /** رفتن به یک روز مشخص در تب «برنامهٔ من» */
  function openDay(dateIso) {
    if (!state.plan) return;
    const idx = state.plan.days.findIndex((d) => d.date === dateIso);
    if (idx < 0) return;
    state.week = Math.floor(idx / 7);
    state.selectedDay = idx;
    gotoView('plan');
    const body = $('planBody');
    if (body) body.style.display = 'block';
    renderWeek();
    const dv = $('dayView');
    if (dv) { try { dv.scrollIntoView({ behavior: 'smooth', block: 'start' }); } catch (e) { /* بی‌صدا */ } }
  }

  function renderHomeToday() {
    const card = $('homeTodayCard');
    if (!card) return;
    const plan = state.plan;
    if (!plan || !plan.days || !plan.days.length) { card.style.display = 'none'; return; }
    card.style.display = 'block';

    const todayIso = iso(new Date());
    let idx = plan.days.findIndex((d) => d.date === todayIso);
    const isToday = idx >= 0;
    if (!isToday) {
      /* امروز خارج از بازهٔ برنامه است: نزدیک‌ترین روز آینده، وگرنه اولین روز */
      idx = plan.days.findIndex((d) => d.date > todayIso);
      if (idx < 0) idx = 0;
    }
    const d = plan.days[idx];
    const mins = dayMinutes(d);
    const blocks = (d.blocks || []).filter((b) => b.kind !== 'exam');
    const tests = dayTests(d);

    const restDay = blocks.length === 0 && (d.isRestDay || d.isOff || !(d.blocks || []).length);
    const list = $('homeTodayList');
    if ($('homeTodayDate')) {
      $('homeTodayDate').textContent = (isToday ? 'امروز · ' : '') + jDateFull(d.date) + ' · ' + d.weekday +
        (restDay ? ' · روز استراحت' : '');
    }
    if ($('homeTodayStats')) {
      /* روز استراحت: به‌جای «۰ ساعت» که نگران‌کننده است، پیام روشن بده */
      if (restDay) {
        const nxt = plan.days.slice(idx + 1).find((x) => (x.blocks || []).length);
        $('homeTodayStats').innerHTML = [
          { v: 'استراحت', l: isToday ? 'امروز' : 'این روز' },
          { v: nxt ? hoursFa(dayMinutes(nxt)) + ' ساعت' : '—', l: nxt ? 'روز بعدی (' + nxt.weekday + ')' : 'روز بعدی' },
          { v: nxt ? jDateFull(nxt.date) : '—', l: 'تاریخ روز بعدی' },
          { v: faNum(plan.summary.coverage.coverageRatio) + '٪', l: 'پوشش کل برنامه' },
        ].map((i) => '<div class="stat"><b>' + i.v + '</b><span>' + i.l + '</span></div>').join('');
        if (list) {
          list.innerHTML = '<div class="issue info" style="cursor:default"><span class="mark">i</span><div class="body">' +
            '<div class="ttl">' + (isToday ? 'امروز' : 'این روز') + ' روز استراحت هفتگی است</div>' +
            '<div class="det">روز استراحت را خودت در «زمان‌های تو» انتخاب کرده‌ای. اگر می‌خواهی امروز هم بخوانی، ' +
            'روز استراحت را عوض کن یا روی «برنامهٔ کامل» برو و به روز بعد سر بزن.</div></div></div>';
        }
        renderAhead(plan, idx);
        return;
      }

      const lastEnd = blocks.reduce((a, b) => Math.max(a, b.end || 0), 0);
      const firstStart = blocks.reduce((a, b) => Math.min(a, b.start || 1440), 1440);
      $('homeTodayStats').innerHTML = [
        { v: hoursFa(mins) + ' ساعت', l: 'مدت مطالعهٔ این روز' },
        { v: faNum(blocks.length), l: 'بلوک کاری' },
        { v: faNum(tests), l: 'تست هدف' },
        { v: blocks.length ? bidi(faNum(String(Math.floor(firstStart / 60)).padStart(2, '0') + ':' + String(firstStart % 60).padStart(2, '0')) + '–' + faNum(String(Math.floor(lastEnd / 60)).padStart(2, '0') + ':' + String(lastEnd % 60).padStart(2, '0'))) : '—', l: 'بازهٔ مطالعه' },
      ].map((i) => '<div class="stat"><b>' + i.v + '</b><span>' + i.l + '</span></div>').join('');
    }

    /* فهرست فشردهٔ بلوک‌های امروز */
    if (list) {
      const evts = (d.events || []).map((e) =>
        '<div class="evt' + (e.type === 'exam' ? ' exam' : '') + '"><span>' + (e.type === 'exam' ? '📝' : '📌') + '</span>' +
        '<b>' + esc(e.title) + '</b><span class="t">' + bidi(faNum(e.start) + '–' + faNum(e.end)) + '</span></div>').join('');
      const items = blocks.slice(0, 5).map((b) =>
        '<div class="block" style="grid-template-columns:86px 1fr"><div class="time">' +
        bidi(faNum(b.start) + '–' + faNum(b.end)) + '<small>' + faNum(b.minutes || (b.end - b.start)) + ' دقیقه</small></div>' +
        '<div><div class="t">' + esc(b.subjectName) + ' <span class="muted" style="font-size:11px">· ' + esc(b.topic) + '</span></div>' +
        '<div class="tech">' + esc(faNum(b.kindLabel || '')) + '</div></div></div>').join('');
      const more = blocks.length > 5
        ? '<div class="muted" style="font-size:11px;margin-top:6px">و ' + faNum(blocks.length - 5) + ' بلوک دیگر — در «برنامهٔ من» ببین.</div>'
        : '';
      list.innerHTML = evts + items + more || '<div class="muted" style="font-size:12px">این روز بلوکی ندارد (استراحت یا تعطیل).</div>';
    }

    renderAhead(plan, idx);
  }

  /* نوار روزهای آینده */
  function renderAhead(plan, idx) {
    const ahead = $('homeAhead');
    if (ahead) {
      const start = idx + 1;
      const days = plan.days.slice(start, start + 8);
      ahead.innerHTML = days.map((x) => {
        const h = hoursFa(dayMinutes(x));
        const n = (x.blocks || []).length;
        return '<button class="aday" data-open-day="' + x.date + '">' +
          '<div class="wd">' + esc(x.weekday) + '</div>' +
          '<div class="dt">' + esc(jDateFull(x.date)) + '</div>' +
          '<div class="hrs">' + h + ' ساعت</div>' +
          '<div class="sub">' + (n ? faNum(n) + ' بلوک' + (dayTests(x) ? ' · ' + faNum(dayTests(x)) + ' تست' : '') : 'استراحت') + '</div>' +
          '</button>';
      }).join('') || '<div class="muted" style="font-size:12px">روز دیگری در برنامه نیست.</div>';
      ahead.querySelectorAll('[data-open-day]').forEach((b) => {
        b.addEventListener('click', () => openDay(b.dataset.openDay));
      });
    }
  }

  /* چیپ‌های پرش داخل گزارش */
  document.querySelectorAll('[data-jump]').forEach((b) => {
    b.addEventListener('click', () => {
      const target = $(b.dataset.jump);
      if (!target) return;
      document.querySelectorAll('[data-jump]').forEach((x) => x.classList.remove('on'));
      b.classList.add('on');
      target.scrollIntoView({ behavior: 'smooth', block: 'start' });
    });
  });

  /* دکمه‌های جهش بین قدم‌ها */
  document.querySelectorAll('[data-goto]').forEach((b) => {
    if (b.classList.contains('chkitem')) return;
    b.addEventListener('click', () => gotoView(b.dataset.goto));
  });
  document.querySelectorAll('[data-next]').forEach((b) => {
    b.addEventListener('click', () => gotoView('step-' + b.dataset.next));
  });
  document.querySelectorAll('[data-back]').forEach((b) => {
    b.addEventListener('click', () => gotoView('step-' + b.dataset.back));
  });

  /* دکمه‌های ساخت برنامه در نوار بالا و نوار کنار و خانه */
  [['buildTop', null], ['buildSide', null], ['homeBuild', null]].forEach(([id]) => {
    const el = $(id);
    if (el) el.addEventListener('click', () => { if ($('build')) $('build').click(); });
  });
  if ($('homeStart')) $('homeStart').addEventListener('click', () => gotoView('step-1'));

  /* ══════════════════════════════════════════════════════════════════
     راهنمای هر فیلد (ⓘ) — برای کسی که مفهوم بخش‌ها را نمی‌داند
     ══════════════════════════════════════════════════════════════════ */
  const HELP = {
    /* — قدم ۱ — */
    name: { t: 'نام', d: 'فقط برای اینکه برنامه به اسم خودت ساخته شود. هر چیزی بنویسی اشکالی ندارد.' },
    grade: { t: 'پایهٔ تحصیلی', d: 'پایه‌ای که امسال در آن درس می‌خوانی. اگر امسال دوازدهمی، «دوازدهم» را انتخاب کن؛ کنکور ۱۴۰۶ برای دوازدهمی‌های امسال است.' },
    field: { t: 'رشته', d: 'رشتهٔ کنکورت. تجربی، ریاضی یا انسانی. ضرایب درس‌ها و حجم فصل‌ها بر اساس همین رشته چیده می‌شود.' },
    chronotype: { t: 'الگوی خواب و بیداری', d: '«سحرخیز» یعنی صبح‌ها بازده بیشتری داری؛ برنامه سنگین‌ترین بلوک‌ها را در بازهٔ اوج تو می‌گذارد. اگر مطمئن نیستی «متعادل» را بگذار.' },
    startDate: { t: 'تاریخ شروع برنامه', d: 'از چه روزی برنامه شروع شود. معمولاً همان امروز. تاریخ‌ها شمسی است.' },
    examDate: { t: 'تاریخ کنکور', d: 'برنامه تا این تاریخ چیده می‌شود و ۳۰ روز آخر خودکار «فاز جمع‌بندی» می‌شود. تاریخ رسمی هنوز اعلام نشده؛ می‌توانی بعداً عوضش کنی.' },
    /* — قدم ۲ — */
    timeMode: { t: 'چطور ساعت‌ها تعیین شود؟', d: '«خودم می‌گویم» = ساعت هر روز را خودت وارد می‌کنی. «خودکار» = فقط سقف را می‌دهی و برنامه بر اساس نیاز واقعی فصل‌ها، ضریب درس‌ها و مهلت‌ها ساعت لازم را خودش تعیین می‌کند.' },
    dailyCap: { t: 'سقف ساعت در روز', d: 'بیشترین ساعتی که حاضر هستی در یک روز بخوانی. برنامه هیچ‌وقت از این بیشتر نمی‌چیند؛ اگر نیاز کمتر بود، کمتر هم می‌گذارد و دلیلش را می‌گوید.' },
    dailyFloor: { t: 'کف ساعت در روز', d: 'کمترین ساعتی که برنامه نباید زیر آن برود (اختیاری). مثلاً اگر می‌خواهی حتی در روزهای سبک هم حداقل ۲ ساعت بخوانی، ۲ بگذار.' },
    availability: { t: 'ساعت مطالعهٔ هر روز', d: 'واقع‌بینانه بنویس، نه آرزومندانه: ساعتی که واقعاً می‌توانی مطالعه کنی (بعد از مدرسه و کلاس). برنامه دقیقاً روی همین عدد چیده می‌شود.' },
    startTimes: { t: 'ساعت شروع مطالعهٔ هر روز', d: 'اولین ساعتی که در آن روز می‌توانی شروع کنی (معمولاً بعد از مدرسه). برنامه از این ساعت به بعد بلوک می‌گذارد.' },
    bedtime: { t: 'ساعت خواب', d: 'برنامه ۴۵ دقیقه قبل از خواب را بافر می‌گذارد. اگر بعد از نیمه‌شب می‌خوابی، مثلاً ۰۰:۳۰ بنویس؛ برنامه این را «بعد از نیمه‌شب» می‌فهمد.' },
    wake: { t: 'ساعت بیداری', d: 'برای تشخیص این‌که ساعت خوابت بعد از نیمه‌شب است و برای تعیین مرز روز استفاده می‌شود.' },
    restDay: { t: 'روز استراحت هفتگی', d: 'یک روز که هیچ بلوکی چیده نشود. استراحت برنامه‌ریزی‌شده، از فرسودگی جلوگیری می‌کند؛ با این حال می‌توانی «بدون روز استراحت» را انتخاب کنی.' },
    blockMinutes: { t: 'طول هر بلوک مطالعه', d: 'مدت یک بلوک تمرکز. ۴۵ دقیقه برای بیشتر دانش‌آموزها بهترین تعادل بین تمرکز و خستگی است.' },
    breakMinutes: { t: 'استراحت بین بلوک‌ها', d: 'فاصلهٔ کوتاه بین دو بلوک. ۱۰ دقیقه استراحت واقعی (بدون گوشی) بازده بلوک بعدی را حفظ می‌کند.' },
    /* — قدم ۳ — */
    classRows: { t: 'کلاس‌های هفتگی', d: 'کلاس‌هایی که ساعتشان ثابت است (مدرسه، آموزشگاه، کلاس آنلاین). برنامه این ساعت‌ها را قفل می‌کند و ۲۰ دقیقه «تثبیت کلاس» بعد از آن می‌گذارد.' },
    examRows: { t: 'آزمون‌های ثابت', d: 'آزمون‌هایی که تاریخشان مشخص است (قلم‌چی، گزینهٔ دو...). سه روز آخر قبل از هر آزمون فقط مرور است و روز بعدش بلوک تحلیل خطا دارد.' },
    offRows: { t: 'روزهای خارج از برنامه', d: 'روزهایی که مسافری یا مهمانی و نمی‌توانی بخوانی. «تعطیل کامل» یعنی هیچ بلوکی چیده نشود؛ «سبک» یعنی بار نصف شود.' },
    /* — قدم ۴ — */
    assessment: { t: 'ارزیابی فصل‌به‌فصل', d: 'برای هر فصل بگو خوانده‌ای یا نه و چقدر مسلطی. برنامه از همین‌جا می‌فهمد کدام فصل «یادگیری از صفر»، کدام «جبران» و کدام فقط «مرور» لازم دارد.' },
    general: { t: 'دروس عمومی', d: 'دروس عمومی (سلامت، هویت اجتماعی، ادبیات، دین و زندگی، عربی، زبان) از مسیر سوابق تحصیلی مدیریت می‌شوند. پایه‌اش را انتخاب کن تا فصل‌هایش اضافه شود.' },
    /* — قدم ۵ — */
    finalsEnabled: { t: 'سوابق تحصیلی', d: 'امتحانات نهایی خرداد، ۶۰٪ نتیجهٔ کنکور ۱۴۰۶ را می‌سازند. این بخش، درس‌های نهایی و بازهٔ خرداد را به برنامه اضافه می‌کند.' },
    finalsTable: { t: 'درس‌های سوابق', d: 'نمرهٔ فعلی و نمرهٔ هدف هر درس + میزان تأثیرش. برنامه به درسی که فاصلهٔ بیشتری تا هدف دارد وقت بیشتری می‌دهد.' },
    /* — قدم ۶ — */
    bookDeadlineRows: { t: 'مهلت کتابی', d: 'مثلاً «پایان زیست تا ۲۹ اسفند». برنامه عقب‌افتادگی را حساب می‌کند و می‌گوید روزی چند دقیقه لازم است.' },
    shortDeadlineRows: { t: 'مهلت کوتاه / آزمون تک‌درس', d: 'مهلت برای یک درس یا یک بازهٔ فصل‌ها. برای آزمون‌های آموزشگاه‌ها هم از همین استفاده کن.' },
    mocksCard: { t: 'آزمون‌های دوره‌ای هفتگی', d: 'هر روز هفته، هر چند هفته یک‌بار، چند آزمون هم‌زمان. برنامه قبلش مرور و بعدش تحلیل خطا می‌گذارد.' },
  };

  let helpTipEl = null;
  function showHelp(anchor, key) {
    const item = HELP[key];
    if (!item || !helpTipEl) return;
    helpTipEl.innerHTML = '<b>' + esc(item.t) + '</b>' + esc(item.d);
    helpTipEl.classList.add('show');
    const r = anchor.getBoundingClientRect();
    const w = Math.min(330, window.innerWidth - 24);
    helpTipEl.style.maxWidth = w + 'px';
    /* در RTL جعبه سمت چپِ آیکن باز می‌شود و اگر جا نبود، سمت راست */
    let left = r.left - w - 10;
    if (left < 12) left = Math.min(window.innerWidth - w - 12, r.right + 10);
    let top = r.bottom + 8;
    const th = helpTipEl.offsetHeight || 90;
    if (top + th > window.innerHeight - 12) top = Math.max(12, r.top - th - 8);
    helpTipEl.style.left = left + 'px';
    helpTipEl.style.top = top + 'px';
  }
  function hideHelp() { if (helpTipEl) helpTipEl.classList.remove('show'); }

  /* ساخت آیکن ⓘ برای هر فیلد ثبت‌شده در HELP */
  function installHelp() {
    helpTipEl = $('helpTip');
    Object.keys(HELP).forEach((key) => {
      const el = $(key) || document.querySelector('[data-help="' + key + '"]');
      if (!el) return;
      if (el.querySelector('.qmark[data-k="' + key + '"]')) return;
      const isForm = /^(INPUT|SELECT|TEXTAREA)$/.test(el.tagName);
      let host = null;
      if (isForm) {
        host = el.parentElement && el.parentElement.querySelector(':scope > label');
        if (!host && el.previousElementSibling && el.previousElementSibling.tagName === 'LABEL') host = el.previousElementSibling;
      }
      if (!host) {
        host = el.closest('.card') ? el.closest('.card').querySelector('h2') : null;
      }
      if (!host) host = el.parentElement;
      if (!host) return;
      const ic = document.createElement('span');
      ic.className = 'qmark';
      ic.dataset.k = key;
      ic.textContent = '?';
      ic.setAttribute('aria-label', HELP[key].t);
      ic.addEventListener('mouseenter', () => showHelp(ic, key));
      ic.addEventListener('mouseleave', hideHelp);
      ic.addEventListener('click', (ev) => {
        ev.preventDefault();
        ev.stopPropagation();
        const on = ic.classList.contains('on');
        document.querySelectorAll('.qmark.on').forEach((x) => x.classList.remove('on'));
        if (on) { hideHelp(); return; }
        ic.classList.add('on');
        showHelp(ic, key);
      });
      host.appendChild(ic);
    });
    document.addEventListener('click', (ev) => {
      if (!ev.target.closest || !ev.target.closest('.qmark')) {
        document.querySelectorAll('.qmark.on').forEach((x) => x.classList.remove('on'));
        hideHelp();
      }
    });
    const scroller = $('mainScroll');
    if (scroller) scroller.addEventListener('scroll', hideHelp, { passive: true });
  }

  /* ══════════════════════════════════════════════════════════════════
     کارت‌های خطا: چرا + چطور رفعش کنم + پرش به همان فیلد
     ══════════════════════════════════════════════════════════════════ */
  function issuesOf(plan) {
    if (!plan || !plan.summary) return [];
    const list = (plan.summary.diagnostics || []).slice();
    /* پیام‌های متنیِ قدیمی که ساخت‌یافته نشده‌اند هم نشان داده می‌شوند */
    const known = {};
    list.forEach((d) => { known[d.detail] = true; });
    (plan.summary.warnings || []).forEach((w) => {
      if (!known[w]) list.push({ id: 'legacy', level: 'warn', title: 'هشدار برنامه', detail: w, fix: '', step: 'step-2', field: '' });
    });
    const rank = { error: 0, warn: 1, info: 2 };
    return list.sort((a, b) => (rank[a.level] || 1) - (rank[b.level] || 1));
  }

  function issueHtml(it) {
    const lvl = it.level === 'error' ? ' err' : (it.level === 'info' ? ' info' : '');
    const mark = it.level === 'error' ? '!' : (it.level === 'info' ? 'i' : '⚠');
    return '<div class="issue' + lvl + '" data-istep="' + esc(it.step || '') + '" data-ifield="' + esc(it.field || '') + '">' +
      '<span class="mark">' + mark + '</span>' +
      '<div class="body">' +
        '<div class="ttl">' + esc(it.title || '') + '</div>' +
        (it.detail ? '<div class="det">' + esc(it.detail) + '</div>' : '') +
        (it.fix ? '<div class="fixline"><b>راه‌حل: </b>' + esc(it.fix) + '</div>' : '') +
      '</div>' +
      (it.step ? '<span class="go">رفع این مورد ‹</span>' : '') +
    '</div>';
  }

  function renderIssues(list, box) {
    if (!box) return;
    if (!list.length) { box.innerHTML = ''; return; }
    box.innerHTML = list.map(issueHtml).join('');
    box.querySelectorAll('.issue').forEach((el) => {
      el.addEventListener('click', () => jumpToIssue(el.dataset.istep, el.dataset.ifield));
    });
  }

  /* پرش: همان قدم را باز می‌کند، به همان فیلد می‌رود و راهنما را نشان می‌دهد */
  function jumpToIssue(step, field) {
    if (!step) return;
    gotoView(step);
    if (!field) return;
    setTimeout(() => {
      let el = $(field);
      if (!el && field === 'availability') el = document.querySelector('[data-avail]');
      if (!el) el = document.querySelector('#view-' + step + ' .card');
      if (!el) return;
      try { el.scrollIntoView({ behavior: 'smooth', block: 'center' }); } catch (e) { /* بی‌صدا */ }
      el.classList.add('fld-flash');
      setTimeout(() => el.classList.remove('fld-flash'), 3200);
      if (el.focus) { try { el.focus({ preventScroll: true }); } catch (e) { /* بی‌صدا */ } }
      const key = HELP[field] ? field : null;
      const kb = el.dataset ? el.dataset.k : null;
      const hintEl = el.parentElement && el.parentElement.querySelector('.qmark');
      if (hintEl && hintEl.dataset && hintEl.dataset.k) {
        document.querySelectorAll('.qmark.on').forEach((x) => x.classList.remove('on'));
        hintEl.classList.add('on');
        showHelp(hintEl, hintEl.dataset.k);
        setTimeout(() => { hintEl.classList.remove('on'); hideHelp(); }, 6000);
      }
      void key; void kb;
    }, 90);
  }

  /* ══════════════════════════════════════════════════════════════════
     حالت زمان‌بندی: دستی / خودکار (فقط سقف)
     ══════════════════════════════════════════════════════════════════ */
  function setTimeMode(mode) {
    state.timeMode = mode === 'auto' ? 'auto' : 'fixed';
    const fixed = $('modeFixed');
    const auto = $('modeAuto');
    if (fixed) fixed.classList.toggle('on', state.timeMode === 'fixed');
    if (auto) auto.classList.toggle('on', state.timeMode === 'auto');
    if ($('autoBox')) $('autoBox').style.display = state.timeMode === 'auto' ? 'block' : 'none';
    if ($('manualBox')) $('manualBox').style.display = state.timeMode === 'auto' ? 'none' : 'block';
  }

  /* ---------------- فرم تنظیمات ---------------- */

  function buildAvailabilityGrid(values) {
    const box = $('availability');
    box.innerHTML = '';
    WEEKDAY_KEY.forEach((k, i) => {
      const div = document.createElement('div');
      div.className = 'avail-cell';
      div.innerHTML = '<label>' + WEEKDAY_FA[i] + ' (ساعت)</label>' +
        '<input type="text" inputmode="decimal" data-avail="' + k + '" value="' + faDigits(values[k] != null ? values[k] : 4) + '" style="text-align:center;font-weight:700;font-size:14px" />';
      box.appendChild(div);
    });
  }

  function subjectRow(s, index) {
    const types = engine.SUBJECT_TYPE_FA;
    const typeOpts = Object.keys(types)
      .map((t) => '<option value="' + t + '"' + (s.type === t ? ' selected' : '') + '>' + types[t] + '</option>')
      .join('');
    const rows = chapterRows(s);
    const s2 = assessSummary(rows);
    return '' +
      '<tr data-row="' + index + '" data-id="' + esc(s.id) + '">' +
      '<td><input data-f="name" value="' + esc(s.name) + '" /></td>' +
      '<td><input data-f="weight" type="number" min="0.5" max="20" step="0.5" value="' + s.weight + '" style="width:64px" /></td>' +
      '<td><span class="muted" style="font-size:12px">' + faNum(s2.readCount) + ' / ' + faNum(s2.total) + '</span></td>' +
      '<td><span class="muted" style="font-size:12px">' + faNum(s2.avg) + '٪</span></td>' +
      '<td><select data-f="difficulty">' +
      [1, 2, 3].map((d) => '<option value="' + d + '"' + (s.difficulty === d ? ' selected' : '') + '>' + ['آسان', 'متوسط', 'سخت'][d - 1] + '</option>').join('') +
      '</select></td>' +
      '<td><select data-f="type">' + typeOpts + '</select></td>' +
      '<td><input data-f="examPercent" type="number" min="-33" max="100" value="' + (s.examPercent == null ? '' : s.examPercent) + '" placeholder="—" style="width:70px" /></td>' +
      '<td><input data-f="include" type="checkbox" ' + (s.include === false ? '' : 'checked') + ' /></td>' +
      '</tr>';
  }

  function esc(s) {
    return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;');
  }

  /* ---------------- ارزیابی فصل به فصل ---------------- */

  function faToEn(t) {
    return String(t).replace(/[۰-۹]/g, (d) => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(d)));
  }

  /** فهرست پیش‌فرض فصل‌های یک درس (نخوانده) */
  function defaultChapterRows(sub) {
    const names = sub && Array.isArray(sub.topicNames) && sub.topicNames.length ? sub.topicNames : null;
    const n = names ? names.length : clampNum(sub && sub.chapters, 1, 120);
    const out = [];
    for (let i = 0; i < n; i++) {
      out.push({
        name: names ? String(names[i]) : ((sub && sub.topicLabel) || 'فصل') + ' ' + faNum(i + 1),
        read: false,
        mastery: 0,
      });
    }
    return out;
  }

  function clampNum(v, lo, hi) {
    const n = Number(v);
    if (!Number.isFinite(n)) return lo;
    return Math.max(lo, Math.min(hi, n));
  }

  /** سطرهای ارزیابی یک درس (منبع حقیقت: state.chapters) */
  function chapterRows(sub) {
    if (!sub || !sub.id) return [];
    if (!state.chapters[sub.id] || !state.chapters[sub.id].length) {
      state.chapters[sub.id] = defaultChapterRows(sub);
    }
    return state.chapters[sub.id];
  }

  /** خلاصهٔ ارزیابی یک درس */
  function assessSummary(rows) {
    const total = rows.length || 1;
    const read = rows.filter((r) => r.read);
    const avgAll = Math.round(rows.reduce((a, r) => a + (r.read ? Number(r.mastery) || 0 : 0), 0) / total);
    const weak = read.filter((r) => r.mastery < 45).length;
    const boost = read.filter((r) => r.mastery >= 45 && r.mastery < 75).length;
    const solid = read.filter((r) => r.mastery >= 75).length;
    return { total: rows.length, readCount: read.length, avg: avgAll, weak, boost, solid };
  }

  /** دروس قابل ارزیابی = اختصاصی‌ها + عمومی‌های فعال */
  function assessSubjects() {
    const core = (state.coreSubjects || []).map((x) => ({
      id: x.id, name: x.name, weight: x.weight, chapters: x.chapters,
      topicLabel: x.topicLabel, topicNames: x.topicNames, general: false,
    }));
    const gen = (state.general || []).filter((x) => x.include !== false).map((x) => ({
      id: x.id, name: x.name, weight: x.weight, chapters: x.chapters,
      topicLabel: x.topicLabel, topicNames: x.topicNames, general: true, grade: x.grade,
    }));
    return core.concat(gen);
  }

  function assessmentRowHtml(row, i) {
    return '<tr data-ci="' + i + '">' +
      '<td><input data-cf="name" value="' + esc(row.name) + '" /></td>' +
      '<td style="text-align:center"><input type="checkbox" data-cf="read"' + (row.read ? ' checked' : '') + ' /></td>' +
      '<td><div class="mrow">' +
        '<input type="number" min="0" max="100" step="5" data-cf="mastery" value="' + (row.read ? row.mastery : 0) + '"' +
          (row.read ? '' : ' disabled') + ' style="width:66px" />' +
        '<span class="muted" style="font-size:11px">٪</span>' +
        [0, 25, 50, 75, 90].map((v) => '<button class="mini" data-set="' + v + '"' + (row.read ? '' : ' disabled') + '>' + faNum(v) + '</button>').join('') +
      '</div></td>' +
      '<td style="text-align:center"><button class="mini del" data-del="' + i + '" title="حذف">✕</button></td>' +
    '</tr>';
  }

  /** رندر کل بخش ارزیابی فصل‌به‌فصل */
  function renderAssessment() {
    const box = $('assessment');
    if (!box) return;
    const subs = assessSubjects();
    if (!subs.length) { box.innerHTML = '<div class="muted">درسی برای ارزیابی نیست.</div>'; return; }

    /* خلاصهٔ کل */
    let allRows = [];
    subs.forEach((sub) => { allRows = allRows.concat(chapterRows(sub)); });
    const g = assessSummary(allRows);
    const filled = g.readCount > 0;

    box.innerHTML =
      '<div class="assess-top">' +
        '<div><b style="font-size:13px">' + faNum(g.total) + ' فصل/درس</b>' +
          '<div class="muted" style="font-size:11.5px;margin-top:3px">' +
            faNum(g.readCount) + ' خوانده‌شده · ' + faNum(g.weak) + ' ضعیف (زیر ۴۵٪) · ' +
            faNum(g.boost) + ' نیازمند ارتقا · ' + faNum(g.solid) + ' مسلط</div></div>' +
        '<div style="flex:1;min-width:160px"><div class="acard-bar" style="height:9px"><i style="width:' + g.avg + '%"></i></div>' +
          '<div class="muted" style="font-size:11px;margin-top:4px">آمادگی فعلی (میانگین وزنی تسلط): ' + faNum(g.avg) + '٪</div></div>' +
        '<div class="row" style="gap:6px">' +
          '<button class="btn ghost small" data-all="open">باز کردن همه</button>' +
          '<button class="btn ghost small" data-all="close">بستن همه</button>' +
        '</div>' +
      '</div>' +
      (!filled
        ? '<div class="hint">هنوز چیزی علامت نزده‌ای. هر درسی که خوانده‌ای را تیک بزن و درصد تسلطش را بزن؛ ' +
          'فصل‌های تیک‌نخورده در برنامه «یادگیری از صفر» و فصل‌های ضعیف خودکار «جبران/ارتقا» می‌گیرند.</div>'
        : '') +
      subs.map((sub) => {
        const rows = chapterRows(sub);
        const s2 = assessSummary(rows);
        const open = state.assessOpen[sub.id] === true;
        return '<div class="acard' + (open ? ' open' : '') + '" data-sid="' + esc(sub.id) + '">' +
          '<div class="acard-h" data-head="' + esc(sub.id) + '">' +
            '<span class="acard-t">' + esc(sub.name) +
              '<small>' + (sub.grade ? esc(sub.grade) + ' · ' : '') + 'ضریب ' + faNum(sub.weight) + ' · ' + faNum(s2.total) + ' ' +
              esc(sub.general ? 'درس' : 'فصل') + '</small></span>' +
            '<span class="acard-m">' + (s2.readCount ? faNum(s2.readCount) + ' از ' + faNum(s2.total) + ' خوانده · میانگین ' + faNum(s2.avg) + '٪' +
              (s2.weak ? ' · <b style="color:#dc2626">' + faNum(s2.weak) + ' ضعیف</b>' : '') : 'ارزیابی نشده') + '</span>' +
            '<div class="acard-bar"><i style="width:' + s2.avg + '%"></i></div>' +
            '<button class="mini" data-toggle="' + esc(sub.id) + '">' + (open ? 'بستن' : 'باز کردن') + '</button>' +
          '</div>' +
          '<div class="acard-b"' + (open ? '' : ' hidden') + '>' +
            '<div class="row" style="gap:6px;margin-bottom:8px;flex-wrap:wrap">' +
              '<button class="btn ghost small" data-fill="' + esc(sub.id) + '" data-val="85">همه را خوانده‌ام (۸۵٪)</button>' +
              '<button class="btn ghost small" data-fill="' + esc(sub.id) + '" data-val="60">همه را خوانده‌ام (۶۰٪)</button>' +
              '<button class="btn ghost small" data-fill="' + esc(sub.id) + '" data-val="0">همه را نخوانده‌ام</button>' +
              '<button class="btn ghost small" data-add="' + esc(sub.id) + '">+ افزودن مبحث</button>' +
            '</div>' +
            '<table class="chap"><thead><tr><th>' + esc(sub.general ? 'درس' : 'فصل / مبحث') +
              '</th><th style="width:74px">خوانده‌ام</th><th style="width:270px">تسلط</th><th style="width:36px"></th></tr></thead><tbody>' +
              rows.map(assessmentRowHtml).join('') +
            '</tbody></table>' +
          '</div>' +
        '</div>';
      }).join('');

    /* رویدادها */
    box.querySelectorAll('[data-head]').forEach((h) => {
      h.addEventListener('click', (ev) => {
        if (ev.target.closest('button')) return;
        const id = h.dataset.head;
        state.assessOpen[id] = !(state.assessOpen[id] === true);
        renderAssessment();
      });
    });
    box.querySelectorAll('[data-all]').forEach((b) => {
      b.addEventListener('click', () => {
        const open = b.dataset.all === 'open';
        subs.forEach((sub) => { state.assessOpen[sub.id] = open; });
        renderAssessment();
      });
    });
    box.querySelectorAll('[data-fill]').forEach((b) => {
      b.addEventListener('click', () => {
        const id = b.dataset.fill;
        const v = Number(b.dataset.val);
        const sub = subs.find((x) => x.id === id);
        const rows = chapterRows(sub);
        rows.forEach((r) => { r.read = v > 0; r.mastery = v > 0 ? v : 0; });
        state.assessOpen[id] = true;
        renderAssessment();
        toast('برای «' + (sub ? sub.name : '') + '» ' + (v > 0 ? 'همه فصل‌ها با تسلط ' + faNum(v) + '٪' : 'همه فصل‌ها نخوانده') + ' ثبت شد.');
      });
    });
    box.querySelectorAll('[data-add]').forEach((b) => {
      b.addEventListener('click', () => {
        const id = b.dataset.add;
        const sub = subs.find((x) => x.id === id);
        const rows = chapterRows(sub);
        rows.push({ name: 'مبحث تازه ' + faNum(rows.length + 1), read: false, mastery: 0 });
        state.assessOpen[id] = true;
        renderAssessment();
      });
    });
    box.querySelectorAll('[data-toggle]').forEach((b) => {
      b.addEventListener('click', () => {
        const id = b.dataset.toggle;
        state.assessOpen[id] = !(state.assessOpen[id] === true);
        renderAssessment();
      });
    });
    box.querySelectorAll('[data-set]').forEach((b) => {
      b.addEventListener('click', () => {
        const tr = b.closest('tr');
        const card = b.closest('.acard');
        const sub = subs.find((x) => x.id === card.dataset.sid);
        const rows = chapterRows(sub);
        const row = rows[Number(tr.dataset.ci)];
        if (!row) return;
        row.read = true;
        row.mastery = Number(b.dataset.set);
        renderAssessment();
      });
    });
    box.querySelectorAll('[data-del]').forEach((b) => {
      b.addEventListener('click', () => {
        const card = b.closest('.acard');
        const sub = subs.find((x) => x.id === card.dataset.sid);
        const rows = chapterRows(sub);
        if (rows.length <= 1) { toast('حداقل یک مبحث باید بماند.'); return; }
        rows.splice(Number(b.dataset.del), 1);
        renderAssessment();
      });
    });
    /* ورودی‌ها: بدون رندر مجدد (تا فوکوس از دست نرود) */
    box.querySelectorAll('.acard').forEach((card) => {
      const sub = subs.find((x) => x.id === card.dataset.sid);
      const rows = chapterRows(sub);
      card.querySelectorAll('tbody tr').forEach((tr) => {
        const i = Number(tr.dataset.ci);
        const row = rows[i];
        if (!row) return;
        const nameEl = tr.querySelector('[data-cf="name"]');
        const readEl = tr.querySelector('[data-cf="read"]');
        const mEl = tr.querySelector('[data-cf="mastery"]');
        if (nameEl) nameEl.addEventListener('input', () => { row.name = nameEl.value; });
        if (readEl) readEl.addEventListener('change', () => {
          row.read = readEl.checked;
          if (row.read && !row.mastery) row.mastery = 50;
          if (mEl) { mEl.disabled = !row.read; mEl.value = row.read ? row.mastery : 0; }
          tr.querySelectorAll('[data-set]').forEach((x) => { x.disabled = !row.read; });
          updateAssessHeader(card, sub);
          updateAssessTop(box, subs);
        });
        if (mEl) mEl.addEventListener('input', () => {
          const v = clampNum(faToEn(mEl.value), 0, 100);
          row.mastery = v;
          if (v > 0) row.read = true;
          updateAssessHeader(card, sub);
          updateAssessTop(box, subs);
        });
      });
    });
  }

  function updateAssessHeader(card, sub) {
    const rows = chapterRows(sub);
    const s2 = assessSummary(rows);
    const m = card.querySelector('.acard-m');
    if (m) {
      m.innerHTML = s2.readCount
        ? faNum(s2.readCount) + ' از ' + faNum(s2.total) + ' خوانده · میانگین ' + faNum(s2.avg) + '٪' +
          (s2.weak ? ' · <b style="color:#dc2626">' + faNum(s2.weak) + ' ضعیف</b>' : '')
        : 'ارزیابی نشده';
    }
    const bar = card.querySelector('.acard-bar i');
    if (bar) bar.style.width = s2.avg + '%';
  }

  function updateAssessTop(box, subs) {
    let allRows = [];
    subs.forEach((sub) => { allRows = allRows.concat(chapterRows(sub)); });
    const g = assessSummary(allRows);
    const top = box.querySelector('.assess-top');
    if (!top) return;
    const sub2 = top.querySelector('div > div.muted');
    if (sub2) {
      sub2.innerHTML = faNum(g.readCount) + ' خوانده‌شده · ' + faNum(g.weak) + ' ضعیف (زیر ۴۵٪) · ' +
        faNum(g.boost) + ' نیازمند ارتقا · ' + faNum(g.solid) + ' مسلط';
    }
    const bar = top.querySelector('.acard-bar i');
    if (bar) bar.style.width = g.avg + '%';
    const lbl = top.querySelectorAll('.muted');
    if (lbl && lbl[1]) lbl[1].textContent = 'آمادگی فعلی (میانگین وزنی تسلط): ' + faNum(g.avg) + '٪';
  }

  /** چسباندن داده‌های ارزیابی فصل‌به‌فصل به یک درس در config */
  function withChapters(sub) {
    const rows = state.chapters[sub.id];
    if (!rows || !rows.length) return sub;
    const s2 = assessSummary(rows);
    return Object.assign({}, sub, {
      chapters: rows.length,
      chaptersData: rows.map((r) => ({ name: r.name, read: !!r.read, mastery: r.read ? clampNum(r.mastery, 0, 100) : 0 })),
      masteredChapters: rows.filter((r) => r.read && r.mastery >= 75).length,
      mastery: s2.avg,
      topicNames: rows.map((r) => r.name),
    });
  }

  function renderSubjects(subjects) {
    state.coreSubjects = (subjects || []).map((s) => Object.assign({}, s));
    const table = $('subjects');
    if (!table) return;
    table.innerHTML = '' +
      '<thead><tr><th>درس</th><th>ضریب</th><th>خوانده / کل</th><th>میانگین تسلط</th><th>سختی</th><th>نوع</th><th>درصد آزمون</th><th>در برنامه</th></tr></thead>' +
      '<tbody>' + (subjects || []).map(subjectRow).join('') + '</tbody>';
    renderAssessment();
  }

  /* ---------------- دروس عمومی ---------------- */

  /** چیپ‌های انتخاب پایه برای دروس عمومی */
  function renderGradeChips() {
    const box = $('generalGrades');
    if (!box) return;
    const grades = presets.grades ? presets.grades() : ['دهم', 'یازدهم', 'دوازدهم'];
    box.innerHTML = grades.map((g) =>
      '<button class="grade-chip' + (state.gradeSel.indexOf(g) !== -1 ? ' on' : '') + '" data-grade="' + esc(g) + '">' +
      esc(g) + '</button>').join('');
    box.querySelectorAll('[data-grade]').forEach((b) => {
      b.addEventListener('click', () => {
        readGeneral(); // ویرایش‌های فعلی را نگه دار
        const g = b.dataset.grade;
        const i = state.gradeSel.indexOf(g);
        if (i === -1) state.gradeSel.push(g);
        else if (state.gradeSel.length > 1) state.gradeSel.splice(i, 1);
        else { toast('حداقل یک پایه باید انتخاب باشد.'); return; }
        renderGeneralForGrades();
      });
    });
  }

  /** ساخت لیست عمومی‌ها بر اساس پایه‌های انتخابی + ویرایش‌های ذخیره‌شده */
  function generalFromGrades() {
    return presets.generalFor(state.gradeSel).map((s) => {
      const edit = state.generalEdits[s.id];
      return edit ? Object.assign({}, s, edit) : s;
    });
  }

  function renderGeneralForGrades() {
    renderGradeChips();
    renderGeneral(generalFromGrades());
  }

  function renderGeneral(list) {
    const rows = (list && list.length ? list : generalFromGrades())
      .map((s) => Object.assign({}, s, { include: s.include !== false }));
    state.general = rows;
    const table = $('general');
    if (!table) return;
    table.innerHTML = '' +
      '<thead><tr><th>درس</th><th>پایه</th><th>ضریب</th><th>خوانده / کل</th><th>میانگین تسلط</th><th>در برنامه</th></tr></thead>' +
      '<tbody>' + rows.map((s) => {
        const _gs = assessSummary(chapterRows(s));
        return '' +
        '<tr data-gid="' + esc(s.id) + '">' +
        '<td><input data-gf="name" value="' + esc(s.name) + '" /></td>' +
        '<td><span class="grade-tag">' + esc(s.grade || '—') + '</span></td>' +
        '<td><input data-gf="weight" type="number" min="0.5" max="20" step="0.5" value="' + s.weight + '" style="width:64px" /></td>' +
        '<td><span class="muted" style="font-size:12px">' + faNum(_gs.readCount) + ' / ' + faNum(_gs.total) + '</span>' +
          '<div class="muted" style="font-size:10px;margin-top:2px">' + esc(s.topicLabel || 'درس') + '</div></td>' +
        '<td><span class="muted" style="font-size:12px">' + faNum(_gs.avg) + '٪</span></td>' +
        '<td><input data-gf="include" type="checkbox" ' + (s.include === false ? '' : 'checked') + ' /></td>' +
        '</tr>';
      }).join('') + '</tbody>';
    renderAssessment();
  }

  function readGeneral() {
    const table = $('general');
    if (!table) return [];
    const byId = {};
    (state.general || []).forEach((s) => { byId[s.id] = s; });
    const out = [];
    table.querySelectorAll('tbody tr').forEach((tr, i) => {
      const get = (f) => tr.querySelector('[data-gf="' + f + '"]');
      const base = byId[tr.dataset.gid] || {};
      const gid = tr.dataset.gid || ('G' + (i + 1));
      const gRows = chapterRows(Object.assign({}, base, { id: gid }));
      const row = Object.assign({}, base, {
        id: gid,
        name: get('name').value.trim() || base.name || ('درس عمومی ' + (i + 1)),
        weight: Number(get('weight').value) || 2,
        chapters: gRows.length,
        masteredChapters: gRows.filter((r) => r.read && r.mastery >= 75).length,
        mastery: assessSummary(gRows).avg,
        include: get('include').checked,
        general: true,
        type: base.type || 'conceptual',
        difficulty: base.difficulty || 2,
        topicLabel: base.topicLabel || 'درس',
        topicNames: base.topicNames || null,
        examPercent: base.examPercent == null ? null : base.examPercent,
      });
      // ویرایش‌ها را برای دفعهٔ بعد (تغییر پایه) نگه دار
      state.generalEdits[row.id] = {
        name: row.name, weight: row.weight, chapters: row.chapters,
        masteredChapters: row.masteredChapters, mastery: row.mastery, include: row.include,
      };
      out.push(row);
    });
    return out;
  }

  /* ---------------- کلاس‌ها و آزمون‌ها ---------------- */

  function subjectOptions(selected) {
    const base = state.config && state.config.subjects ? state.config.subjects.filter((x) => !x.general) : presets.subjectsFor('tajrobi');
    const subs = base.concat((state.general || []).map((x) => ({ id: x.id, name: x.name })));
    return subs.map((x) => '<option value="' + esc(x.id) + '"' + (selected === x.id ? ' selected' : '') + '>' + esc(x.name) + '</option>').join('');
  }

  function renderClassRows(classes) {
    const box = $('classRows');
    box.innerHTML = '';
    (classes && classes.length ? classes : []).forEach((c, i) => {
      const div = document.createElement('div');
      div.className = 'dyn-row class';
      div.innerHTML =
        '<div><label>عنوان کلاس</label><input data-cf="title" value="' + esc(c.title || '') + '" placeholder="مثلاً کلاس زیست" /></div>' +
        '<div><label>درس</label><select data-cf="subjectId">' + subjectOptions(c.subjectId) + '</select></div>' +
        '<div><label>روز</label><select data-cf="weekday">' +
          WEEKDAY_FA.map((w, k) => '<option value="' + k + '"' + ((c.weekdays || [])[0] === k ? ' selected' : '') + '>' + w + '</option>').join('') +
        '</select></div>' +
        '<div><label>از</label>' + timeInput('data-cf="start"', c.start, '18:00') + '</div>' +
        '<div><label>تا</label>' + timeInput('data-cf="end"', c.end, '20:00') + '</div>' +
        '<button class="del" title="حذف">✕</button>';
      div.querySelector('.del').addEventListener('click', () => { div.remove(); toast('کلاس حذف شد — برای اعمال، برنامه را دوباره بساز.'); });
      box.appendChild(div);
    });
    if (!box.children.length) box.innerHTML = '<div class="muted" style="font-size:11.5px">کلاسی اضافه نشده.</div>';
  }

  function renderExamRows(exams) {
    const box = $('examRows');
    box.innerHTML = '';
    (exams && exams.length ? exams : []).forEach((e) => {
      const div = document.createElement('div');
      div.className = 'dyn-row exam';
      div.innerHTML =
        '<div><label>عنوان آزمون</label><input data-ef="title" value="' + esc(e.title || '') + '" placeholder="آزمون آزمایشی" /></div>' +
        '<div><label>تاریخ (شمسی)</label><input data-ef="date" data-jdate data-iso="' + esc(e.date || '') + '" placeholder="۱۴۰۵/۰۹/۱۲" /></div>' +
        '<div><label>از</label>' + timeInput('data-ef="start"', e.start, '08:00') + '</div>' +
        '<div><label>تا</label>' + timeInput('data-ef="end"', e.end, '11:30') + '</div>' +
        '<div><label>درس‌های آزمون</label><select multiple data-ef="subjectIds">' +
          (state.config ? state.config.subjects : []).concat(state.general || []).map((x) =>
            '<option value="' + esc(x.id) + '"' + ((e.subjectIds || []).indexOf(x.id) !== -1 ? ' selected' : '') + '>' + esc(x.name) + '</option>').join('') +
        '</select></div>' +
        '<button class="del" title="حذف">✕</button>';
      div.querySelector('.del').addEventListener('click', () => { div.remove(); toast('آزمون حذف شد — برای اعمال، برنامه را دوباره بساز.'); });
      box.appendChild(div);
    });
    if (!box.children.length) box.innerHTML = '<div class="muted" style="font-size:11.5px">آزمونی اضافه نشده.</div>';
    else if (J) J.attachAll(box);
  }

  function readClasses() {
    const out = [];
    $('classRows').querySelectorAll('.dyn-row').forEach((row) => {
      const get = (f) => row.querySelector('[data-cf="' + f + '"]');
      out.push({
        title: get('title').value.trim() || 'کلاس آنلاین',
        subjectId: get('subjectId').value || null,
        weekdays: [Number(get('weekday').value)],
        start: readTime(get('start'), '18:00'),
        end: readTime(get('end'), '20:00'),
      });
    });
    return out;
  }

  function readExams() {
    const out = [];
    $('examRows').querySelectorAll('.dyn-row').forEach((row) => {
      const get = (f) => row.querySelector('[data-ef="' + f + '"]');
      const dateInput = get('date');
      const date = dateInput.dataset.iso || (J ? J.parse(dateInput.value) : null);
      if (!date) return;
      const sel = get('subjectIds');
      out.push({
        title: get('title').value.trim() || 'آزمون آزمایشی',
        date,
        start: readTime(get('start'), '08:00'),
        end: readTime(get('end'), '11:30'),
        subjectIds: Array.prototype.map.call(sel.selectedOptions, (o) => o.value),
      });
    });
    return out;
  }

  $('addClass').addEventListener('click', () => {
    const rows = readClasses();
    rows.push({ title: '', subjectId: null, weekdays: [0], start: '18:00', end: '20:00' });
    renderClassRows(rows);
  });

  $('addExam').addEventListener('click', () => {
    const rows = readExams();
    const d = new Date(); d.setDate(d.getDate() + 14);
    rows.push({ title: 'آزمون آزمایشی', date: J ? J.dateToISO(d) : iso(d), start: '08:00', end: '11:30', subjectIds: [] });
    renderExamRows(rows);
  });

  function readSubjects() {
    const rows = $('subjects').querySelectorAll('tbody tr');
    const out = [];
    rows.forEach((tr, i) => {
      const get = (f) => tr.querySelector('[data-f="' + f + '"]');
      const id = tr.dataset.id || ('S' + (i + 1));
      const base = (state.coreSubjects || []).find((x) => x.id === id) || {};
      const rows = chapterRows(base.id ? base : { id: id, chapters: 1 });
      out.push({
        id: id,
        name: get('name').value.trim() || 'درس ' + (i + 1),
        weight: Number(get('weight').value) || 1,
        chapters: rows.length,
        masteredChapters: rows.filter((r) => r.read && r.mastery >= 75).length,
        mastery: assessSummary(rows).avg,
        difficulty: Number(get('difficulty').value) || 2,
        type: get('type').value,
        examPercent: get('examPercent').value === '' ? null : Number(get('examPercent').value),
        include: get('include').checked,
        topicLabel: base.topicLabel || 'فصل',
        topicNames: rows.map((r) => r.name),
      });
    });
    return out;
  }

  function collectConfig() {
    const availability = {};
    document.querySelectorAll('[data-avail]').forEach((inp) => {
      availability[inp.dataset.avail] = numVal(inp);
    });
    const subjects = readSubjects()
      .concat(readGeneral().filter((x) => x.include))
      .map(withChapters);
    const schoolDays = { sat: '16:00', sun: '16:00', mon: '16:00', tue: '16:00', wed: '16:00', thu: '09:00', fri: '09:00' };
    return {
      student: {
        name: $('name').value.trim() || 'دانش‌آموز',
        grade: $('grade').value,
        field: $('field').value,
        chronotype: $('chronotype').value,
      },
      startDate: readJDate('startDate') || iso(new Date()),
      examDate: readJDate('examDate') || presets.defaultExamDate(),
      sleep: { bedtime: readTime($('bedtime'), '23:30'), wake: readTime($('wake'), '07:00') },
      availability,
      timeMode: state.timeMode === 'auto' ? 'auto' : 'fixed',
      dailyCapHours: numVal($('dailyCap')) || 8,
      dailyFloorHours: numVal($('dailyFloor')) || 1,
      startTimes: schoolDays,
      blockMinutes: Number($('blockMinutes').value) || 45,
      breakMinutes: Number($('breakMinutes').value) || 10,
      restDay: Number($('restDay').value),
      weeklyMock: $('weeklyMock').value === '1',
      weeklyMocks: readMocks(),
      classes: readClasses(),
      exams: readExams(),
      generalGrades: state.gradeSel.slice(),
      subjects,
      startTimes: readStartTimes(),
      offDates: readOffRows(),
      deadlines: { books: readBookDeadlines(), exams: readShortDeadlines() },
      finals: {
        enabled: ($('finalsEnabled') || {}).value !== '0',
        courses: readFinals(),
        window: {
          start: readJDate('finalsStart') || (presets.defaultFinalsWindow ? presets.defaultFinalsWindow().start : null),
          end: readJDate('finalsEnd') || (presets.defaultFinalsWindow ? presets.defaultFinalsWindow().end : null),
        },
        spread: ($('finalsSpread') || {}).value !== '0',
        spreadMinutes: Number(($('finalsSpreadMinutes') || {}).value) || 45,
      },
    };
  }

  function applyConfigToForm(cfg) {
    state.config = cfg;
    $('name').value = (cfg.student && cfg.student.name) || '';
    $('grade').value = (cfg.student && cfg.student.grade) || 'دوازدهم';
    $('field').value = (cfg.student && cfg.student.field) || 'tajrobi';
    $('chronotype').value = (cfg.student && cfg.student.chronotype) || 'neutral';
    writeJDate('startDate', cfg.startDate || iso(new Date()));
    writeJDate('examDate', cfg.examDate || presets.defaultExamDate());
    if ($('dailyCap')) $('dailyCap').value = faDigits(cfg.dailyCapHours != null ? cfg.dailyCapHours : 8);
    if ($('dailyFloor')) $('dailyFloor').value = faDigits(cfg.dailyFloorHours != null ? cfg.dailyFloorHours : 1);
    setTimeMode(cfg.timeMode === 'auto' ? 'auto' : 'fixed');
    $('bedtime').value = timeFa((cfg.sleep && cfg.sleep.bedtime) || '23:30');
    $('wake').value = timeFa((cfg.sleep && cfg.sleep.wake) || '07:00');
    $('restDay').value = String(cfg.restDay == null ? 5 : cfg.restDay);
    $('blockMinutes').value = String(cfg.blockMinutes || 45);
    $('breakMinutes').value = String(cfg.breakMinutes == null ? 10 : cfg.breakMinutes);
    $('weeklyMock').value = cfg.weeklyMock === false ? '0' : '1';
    state.weeklyMocks = cfg.weeklyMocks || [];
    renderMockRows(state.weeklyMocks);
    buildAvailabilityGrid(cfg.availability || {});
    const allSubs = cfg.subjects || presets.subjectsFor('tajrobi');
    /* ارزیابی فصل‌به‌فصل ذخیره‌شده را برگردان */
    state.chapters = {};
    allSubs.forEach((sub) => {
      if (Array.isArray(sub.chaptersData) && sub.chaptersData.length) {
        state.chapters[sub.id] = sub.chaptersData.map((c) => ({
          name: String(c.name || ''),
          read: Boolean(c.read),
          mastery: clampNum(c.mastery, 0, 100),
        }));
      }
    });
    const core = allSubs.filter((x) => !x.general);
    const gen = allSubs.filter((x) => x.general);
    renderSubjects(core.length ? core : presets.subjectsFor(cfg.student && cfg.student.field || 'tajrobi'));

    /* پایه‌های عمومی: از config، وگرنه از خودِ دروس ذخیره‌شده، وگرنه پایهٔ دانش‌آموز */
    const cfgGrades = cfg.generalGrades && cfg.generalGrades.length
      ? presets.normalizeGrades(cfg.generalGrades)
      : presets.normalizeGrades(gen.length ? gen.map((g) => g.grade).filter(Boolean) : ((cfg.student && cfg.student.grade) || 'دوازدهم'));
    state.gradeSel = cfgGrades;
    gen.forEach((g) => {
      state.generalEdits[g.id] = {
        name: g.name, weight: g.weight, chapters: g.chapters,
        masteredChapters: g.masteredChapters, mastery: g.mastery, include: g.include,
      };
    });
    renderGeneralForGrades();
    renderClassRows(cfg.classes || []);
    renderExamRows(cfg.exams || []);

    /* --- ساعت شروع، روزهای خارج از برنامه، مهلت‌ها، سوابق --- */
    renderStartTimes(cfg.startTimes || DEFAULT_START_TIMES);
    state.offDates = cfg.offDates || [];
    renderOffRows(state.offDates);
    state.deadlineBooks = (cfg.deadlines && cfg.deadlines.books) || [];
    state.deadlineExams = (cfg.deadlines && cfg.deadlines.exams) || [];
    renderBookDeadlineRows(state.deadlineBooks);
    renderShortDeadlineRows(state.deadlineExams);

    const fcfg = cfg.finals || {};
    const fgrade = (fcfg.courses && fcfg.courses[0] && fcfg.courses[0].grade) ||
      (cfg.student && cfg.student.grade === 'یازدهم' ? 'یازدهم' : 'دوازدهم');
    if ($('finalsEnabled')) $('finalsEnabled').value = fcfg.enabled === false ? '0' : '1';
    if ($('finalsGrade')) $('finalsGrade').value = fgrade;
    if ($('finalsSpread')) $('finalsSpread').value = fcfg.spread === false ? '0' : '1';
    if ($('finalsSpreadMinutes')) $('finalsSpreadMinutes').value = String(fcfg.spreadMinutes || 45);
    const win = presets.defaultFinalsWindow ? presets.defaultFinalsWindow() : { start: null, end: null };
    writeJDate('finalsStart', (fcfg.window && fcfg.window.start) || win.start);
    writeJDate('finalsEnd', (fcfg.window && fcfg.window.end) || win.end);
    if (fcfg.courses && fcfg.courses.length) {
      state.finalsList = fcfg.courses.map((c) => ({
        id: c.id, name: c.name, grade: c.grade || fgrade, influence: c.influence || 3, target: c.target == null ? 18 : c.target,
      }));
      state.finals = {};
      fcfg.courses.forEach((c) => {
        state.finals[c.id] = { current: c.current == null ? null : c.current, target: c.target == null ? 18 : c.target, inProgram: c.inProgram !== false };
      });
      renderFinalsTable();
    } else {
      loadFinalsFor(fgrade);
    }
  }

  function defaultConfig() {
    const field = $('field').value || 'tajrobi';
    return {
      student: {
        name: $('name').value.trim() || 'دانش‌آموز',
        grade: $('grade').value,
        field,
        chronotype: $('chronotype').value,
      },
      startDate: iso(new Date()),
      examDate: presets.defaultExamDate(),
      sleep: { bedtime: '23:30', wake: '07:00' },
      timeMode: 'fixed', dailyCapHours: 8, dailyFloorHours: 1,
      availability: { sat: 4, sun: 4, mon: 4, tue: 4, wed: 4, thu: 6, fri: 5 },
      startTimes: { sat: '16:00', sun: '16:00', mon: '16:00', tue: '16:00', wed: '16:00', thu: '09:00', fri: '09:00' },
      blockMinutes: 45,
      breakMinutes: 10,
      restDay: 5,
      weeklyMock: true,
      weeklyMocks: [{ title: 'آزمون جامع هفتگی', day: 5, everyNWeeks: 1, minutes: 100, subjectIds: [] }],
      classes: [],
      exams: [],
      generalGrades: state.gradeSel.slice(),
      subjects: presets.subjectsFor(field).concat(generalFromGrades()),
      startTimes: Object.assign({}, DEFAULT_START_TIMES),
      offDates: [],
      /* پیش‌فرض: هر دو مدل مهلت از روز اول دیده شوند (قابل حذف/ویرایش) */
      deadlines: {
        books: presets.suggestedBookDeadlines ? presets.suggestedBookDeadlines(presets.subjectsFor(field)) : [],
        exams: [],
      },
      finals: {
        enabled: true,
        courses: finalsDefaults(field, $('grade').value || 'دوازدهم'),
        window: presets.defaultFinalsWindow ? presets.defaultFinalsWindow() : { start: null, end: null },
        spread: true,
        spreadMinutes: 45,
      },
    };
  }

  $('field').addEventListener('change', () => {
    presets.subjectsFor($('field').value).forEach((s) => {
      const keep = state.chapters[s.id];
      state.chapters[s.id] = (keep && keep.length === s.chapters) ? keep : defaultChapterRows(s);
    });
    renderSubjects(presets.subjectsFor($('field').value));
    toast('دروس پیش‌فرض گروه تغییر کرد — ارزیابی فصل‌ها را بازبینی کن.');
  });

  $('resetSubjects').addEventListener('click', () => {
    presets.subjectsFor($('field').value).forEach((s) => {
      state.chapters[s.id] = defaultChapterRows(s);
    });
    renderSubjects(presets.subjectsFor($('field').value));
    toast('دروس و ارزیابی فصل‌ها بازگردانی شد.');
  });

  $('grade').addEventListener('change', () => {
    readGeneral();
    state.gradeSel = presets.normalizeGrades($('grade').value);
    state.generalEdits = {};
    renderGeneralForGrades();
    toast('دروس عمومی پایهٔ ' + $('grade').value + ' بارگذاری شد (قابل تغییر از بخش ۶).');
  });

  $('resetGeneral').addEventListener('click', () => {
    state.generalEdits = {};
    renderGeneralForGrades();
    toast('دروس عمومی پایه‌های انتخابی بازگردانی شد.');
  });

  $('toggleGeneral').addEventListener('click', () => {
    const rows = readGeneral();
    const anyOn = rows.some((r) => r.include);
    rows.forEach((r) => { r.include = !anyOn; });
    renderGeneralForGrades();
  });

  /* ---------------- ساخت برنامه ---------------- */

  $('build').addEventListener('click', async () => {
    const btn = $('build');
    btn.disabled = true;
    const old = btn.textContent;
    btn.innerHTML = '<span class="spinner"></span> در حال ساخت…';
    try {
      const cfg = collectConfig();
      const plan = engine.createPlan(cfg);
      try {
        window.__revalDebug = {
          cfg: { timeMode: cfg.timeMode, dailyCapHours: cfg.dailyCapHours, availability: cfg.availability, startDate: cfg.startDate, examDate: cfg.examDate },
          auto: plan.summary.autoInfo,
          summary: { totalHours: plan.summary.totalHours, avg: plan.summary.avgHoursPerDay, days: plan.days.length, cov: plan.summary.coverage.coverageRatio },
          metaCfg: { autoHours: plan.meta.config.autoHours, timeMode: plan.meta.config.timeMode, avail: plan.meta.config.availability },
        };
      } catch (e) { /* بی‌صدا */ }
      state.config = cfg;
      state.plan = plan;
      state.week = 0;
      state.selectedDay = null;
      state.scores = {};
      state.done = {};
      state.visited = { 'step-1': true, 'step-2': true, 'step-3': true, 'step-4': true, 'step-5': true, 'step-6': true };
      renderPlan();
      renderReport();
      renderHome();
      gotoView('plan');
      toast('برنامه ساخته شد ✓');
      await persist();
    } catch (err) {
      toast('خطا: ' + err.message);
      console.error(err);
    } finally {
      btn.disabled = false;
      btn.textContent = old;
    }
  });

  /* ---------------- نمایش برنامه ---------------- */

  function renderPlan() {
    const plan = state.plan;
    if (!plan) return;
    $('planEmpty').style.display = 'none';
    $('planBody').style.display = 'block';

    const s = plan.summary;
    $('stats').innerHTML = [
      stat(faNum(s.totalHours), 'ساعت برنامه‌ریزی‌شده'),
      stat(faNum(s.avgHoursPerDay), 'میانگین ساعت روزانه'),
      stat(faNum(s.learnedTopics), 'مبحث پوشش‌داده‌شده'),
      stat(faNum(s.totalReviewEvents), 'جلسهٔ مرور فاصله‌دار'),
      stat(faNum(s.classFixBlocks || 0), 'تثبیت کلاس'),
      stat(faNum(s.examDays || 0), 'روز آزمون'),
    ].join('');

    $('coachNotes').innerHTML = s.coachNotes.map((n) => '<li>' + esc(n) + '</li>').join('');
    const issues = issuesOf(plan);
    renderIssues(issues, $('warnBox'));
    renderIssues(issues, $('issueBox'));

    const maxMinutes = Math.max.apply(null, s.bySubject.map((x) => x.minutes).concat([1]));
    $('subjectBars').innerHTML = s.bySubject.map((x) => {
      const w = Math.round((x.minutes / maxMinutes) * 100);
      return '<div style="margin-bottom:10px">' +
        '<div class="row" style="justify-content:space-between"><span style="font-size:12.5px">' + esc(x.name) + '</span>' +
        '<span class="muted" style="font-size:11.5px">' + faNum(x.hours) + ' ساعت · ضریب ' + faNum(x.weight) +
        ' · سهم ' + faNum(Math.round(x.sharePlanned * 100)) + '٪</span></div>' +
        '<div class="bar"><i style="width:' + w + '%"></i></div></div>';
    }).join('');

    renderCoach(plan);
    renderWeek();
    renderScoreGrid();
  }

  /* ---------------- تب گزارش و آنالیز ---------------- */

  function progressBar(pct) {
    const v = Math.max(0, Math.min(100, Math.round(pct)));
    return '<div class="bar" style="min-width:60px"><i style="width:' + v + '%"></i></div>' +
      '<span class="muted" style="font-size:10.5px">' + faNum(v) + '٪</span>';
  }

  function statusPill(st) {
    const m = DL_STATUS[st] || { fa: st, cls: 'warn' };
    return '<span class="pill ' + m.cls + '">' + esc(m.fa) + '</span>';
  }

  function renderReport() {
    const plan = state.plan;
    if (!plan) {
      if ($('reportEmpty')) $('reportEmpty').style.display = 'block';
      if ($('reportBody')) $('reportBody').style.display = 'none';
      return;
    }
    $('reportEmpty').style.display = 'none';
    $('reportBody').style.display = 'block';
    const c = plan.summary.coverage;

    $('reportStats').innerHTML = [
      stat(faNum(c.coverageRatio) + '٪', 'پوشش فصل‌ها'),
      stat(faNum(c.readiness) + ' → ' + faNum(c.projectedReadiness) + '٪', 'آمادگی کنکور (اکنون → پایان)'),
      stat(faNum(c.finalsReadiness) + '٪', 'آمادگی سوابق تحصیلی'),
      stat(faNum(c.composite) + '٪', 'نمرهٔ ترکیبی ۱۴۰۶ (۴۰/۶۰)'),
    ].join('');

    /* --- مهلت‌های کتابی --- */
    const books = c.deadlineBooks || [];
    $('bookDeadlineTable').innerHTML = books.length
      ? '<table class="chap"><thead><tr><th>کتاب</th><th>مهلت</th><th>وضعیت</th><th>فصل</th>' +
        '<th>زمان چیده‌شده / لازم</th><th>تمام‌شدن</th></tr></thead><tbody>' +
        books.map((d) => '<tr><td><b style="font-size:12px">' + esc(d.subjectName) + '</b></td>' +
          '<td>' + faNum(J ? J.fmt(d.date) : d.date) + '</td>' +
          '<td>' + statusPill(d.status) + '</td>' +
          '<td>' + faNum(d.doneChapters) + ' از ' + faNum(d.chapters) + '</td>' +
          '<td><span class="num">' + faNum(Math.round(d.plannedMinutes / 60)) + ' / ' + faNum(Math.round(d.needMinutes / 60)) + '</span> ساعت</td>' +
          '<td>' + (d.finishDate ? faNum(J ? J.fmt(d.finishDate) : d.finishDate) : '—') + '</td></tr>').join('') +
        '</tbody></table>'
      : '<div class="muted" style="font-size:12px">مهلت کتابی ثبت نشده. از تب تنظیمات، بخش ۸ اضافه کن.</div>';

    /* --- مهلت‌های کوتاه --- */
    const exams = c.deadlineExams || [];
    $('shortDeadlineTable').innerHTML = exams.length
      ? '<table class="chap"><thead><tr><th>آزمون</th><th>نوع</th><th>تاریخ</th><th>وضعیت</th>' +
        '<th>فصل‌های آماده</th><th>زمان چیده‌شده / لازم</th></tr></thead><tbody>' +
        exams.map((d) => '<tr><td><b style="font-size:12px">' + esc(d.title) + '</b>' +
          (d.subjectName && d.kind === 'single' ? '<div class="muted" style="font-size:10.5px">' + esc(d.subjectName) + '</div>' : '') + '</td>' +
          '<td>' + (d.kind === 'comprehensive' ? 'جامع' : 'تک‌درس') + '</td>' +
          '<td>' + faNum(J ? J.fmt(d.date) : d.date) + '</td>' +
          '<td>' + statusPill(d.status) + '</td>' +
          '<td>' + faNum(d.doneChapters) + ' از ' + faNum(d.chapters) + '</td>' +
          '<td>' + faNum(Math.round(d.plannedMinutes / 60 * 10) / 10) + ' / ' + faNum(Math.round(d.needMinutes / 60 * 10) / 10) + ' ساعت</td></tr>').join('') +
        '</tbody></table>'
      : '<div class="muted" style="font-size:12px">آزمون تک‌درس یا جامعی ثبت نشده. از تب تنظیمات، بخش ۹ اضافه کن.</div>';

    /* --- سوابق تحصیلی --- */
    const fc = c.finalsCourses || [];
    $('finalsReport').innerHTML = fc.length
      ? '<p class="muted" style="margin-top:0;font-size:11.5px">نمرهٔ فعلی، برآورد پایان دوره و زمانی که برنامه برای هر درس گذاشته است. ' +
        'اگر نمره‌ای ثبت نکرده باشی، «فرض ۱۲» علامت می‌خورد.</p>' +
        '<table class="chap"><thead><tr><th>درس</th><th>ضریب</th><th>فعلی</th><th>هدف</th><th>برآورد پایان</th>' +
        '<th>زمان چیده‌شده / لازم</th><th style="width:130px">پیشرفت</th></tr></thead><tbody>' +
        fc.map((x) => '<tr><td><b style="font-size:12px">' + esc(x.name) + '</b>' +
          (x.assumed ? ' <span class="pill warm" title="نمره ثبت نشده">فرض</span>' : '') + '</td>' +
          '<td>' + faNum(x.influence) + '</td>' +
          '<td>' + faNum(Math.round(x.current * 10) / 10) + '</td>' +
          '<td>' + faNum(x.target) + '</td>' +
          '<td><b>' + faNum(Math.round((x.projected / 100) * 20 * 10) / 10) + '</b></td>' +
          '<td><span class="num">' + faNum(Math.round(x.plannedMinutes / 60 * 10) / 10) + ' / ' + faNum(Math.round(x.needMinutes / 60 * 10) / 10) + '</span> ساعت</td>' +
          '<td>' + progressBar(x.progress) + '</td></tr>').join('') +
        '</tbody></table>'
      : '<div class="muted" style="font-size:12px">لایهٔ سوابق غیرفعال است (تنظیمات، بخش ۱۰).</div>';

    /* --- ظرفیت و استاندارد --- */
    const adv = c.capacityAdvisory || {};
    const covOk = c.coverageRatio >= 98;
    $('capacityBox').innerHTML =
      '<div class="grid g3">' +
        '<div class="kpi"><b>' + faNum(adv.declaredDailyHours || 0) + ' ساعت</b><span>ساعت اعلامی تو در روز</span></div>' +
        '<div class="kpi"><b>' + faNum(adv.minDailyHoursNeeded || 0) + ' ساعت</b><span>حداقل لازم برای پوشش کامل</span></div>' +
        '<div class="kpi"><b>' + faNum(Math.round((adv.fixedWeeklyMinutes || 0) / 60 * 10) / 10) + ' ساعت</b><span>کلاس/آزمون ثابت در هفته</span></div>' +
      '</div>' +
      '<p style="margin:10px 0 0;font-size:12.5px;' + (covOk ? 'color:#047857' : 'color:#b45309') + '">' +
        (covOk
          ? '✓ با ساعت‌های فعلی، پوشش کامل فصل‌ها در دسترس است.'
          : '⚠ با ساعت‌های فعلی پوشش ' + faNum(c.coverageRatio) + '٪ می‌شود. ' +
            'برای پوشش کامل روزی حداقل ' + faNum(adv.minDailyHoursNeeded) + ' ساعت لازم است؛ ' +
            'می‌توانی ساعت‌ها را بالا ببری (تا ۱۶ ساعت را پشتیبانی می‌کند) یا چند فصل کم‌ضریب را عقب بیندازی.') +
      '</p>' +
      '<p class="muted" style="margin:6px 0 0;font-size:11.5px">' +
        'ظرفیت تست: هدف ' + faNum(c.testTargetDaily) + ' تست در روز · ' +
        'میانگین واقعی برنامه ' + faNum(c.testsPerDay) + ' تست · ' +
        'لازم برای استاندارد ' + faNum(c.requiredDailyTests || 0) + ' تست در روز.' +
      '</p>';

    /* --- ظرفیت تست هر درس --- */
    const tRows = c.testsBySubject || [];
    $('testCapacityTable').innerHTML = tRows.length
      ? '<table class="chap"><thead><tr><th>درس</th><th>تست لازم</th><th>چیده‌شده</th><th>پوشش</th><th style="width:130px">پیشرفت</th></tr></thead><tbody>' +
        tRows.map((t) => {
          const pct = t.need > 0 ? Math.min(100, Math.round((t.planned / t.need) * 100)) : 100;
          return '<tr><td><b style="font-size:12px">' + esc(t.name) + '</b></td>' +
            '<td class="num">' + faNum(t.need) + '</td>' +
            '<td class="num">' + faNum(t.planned) + '</td>' +
            '<td>' + faNum(pct) + '٪</td>' +
            '<td>' + progressBar(pct) + '</td></tr>';
        }).join('') + '</tbody></table>'
      : '<div class="muted" style="font-size:12px">داده‌ای نیست.</div>';

    /* --- آزمون‌های دوره‌ای --- */
    const mocks = (plan.meta && plan.meta.weeklyMocks) || state.weeklyMocks || [];
    $('mocksReport').innerHTML = mocks.length
      ? '<table class="chap"><thead><tr><th>آزمون</th><th>روز</th><th>تکرار</th><th>مدت</th><th>دروس</th></tr></thead><tbody>' +
        mocks.map((m) => '<tr><td><b style="font-size:12px">' + esc(m.title) + '</b></td>' +
          '<td>' + (WEEKDAYS_FA[Number(m.day) || 0] || '—') + '</td>' +
          '<td>' + (Number(m.everyNWeeks) <= 1 ? 'هر هفته' : 'هر ' + faNum(m.everyNWeeks) + ' هفته') + '</td>' +
          '<td class="num">' + faNum(m.minutes) + ' دقیقه</td>' +
          '<td>' + ((m.subjectIds || []).length ? (m.subjectIds || []).map((id) => {
            const sub = (plan.meta.subjects || []).find((x) => x.id === id);
            return esc(sub ? sub.name : id);
          }).join('، ') : 'همه دروس') + '</td></tr>').join('') +
        '</tbody></table>'
      : '<div class="muted" style="font-size:12px">آزمون دوره‌ای تعریف نشده.</div>';

    renderBookTable(plan);
    renderChapterTable(plan);
    renderReportFilters(plan);
  }

  function renderReportFilters(plan) {
    const sel = $('reportBook');
    if (!sel) return;
    const cur = sel.value || 'all';
    const subs = (plan.summary.bySubject || []).filter((x) => plan.summary.chapterStats.some((c) => c.subjectId === x.id));
    sel.innerHTML = '<option value="all">همهٔ کتاب‌ها</option>' +
      subs.map((x) => '<option value="' + esc(x.id) + '">' + esc(x.name) + '</option>').join('');
    sel.value = subs.some((x) => x.id === cur) ? cur : 'all';
    renderChapterTable(plan);
  }

  function renderBookTable(plan) {
    const chs = plan.summary.chapterStats || [];
    const rows = (plan.summary.bySubject || []).map((sub) => {
      const list = chs.filter((c) => c.subjectId === sub.id);
      if (!list.length) return null;
      const need = list.reduce((a, c) => a + c.needMinutes, 0);
      const planned = list.reduce((a, c) => a + c.plannedMinutes, 0);
      const testsNeed = list.reduce((a, c) => a + c.testsNeed, 0);
      const testsDone = list.reduce((a, c) => a + c.testsDone, 0);
      const covered = list.filter((c) => c.covered).length;
      const mastery = Math.round(list.reduce((a, c) => a + c.mastery, 0) / list.length);
      const reviews = list.reduce((a, c) => a + (c.reviews || 0), 0);
      return '<tr><td><b style="font-size:12px">' + esc(sub.name) + '</b>' +
        '<div class="muted" style="font-size:10.5px">ضریب ' + faNum(sub.weight) + '</div></td>' +
        '<td>' + faNum(covered) + ' / ' + faNum(list.length) + '</td>' +
        '<td>' + faNum(Math.round(covered / list.length * 100)) + '٪</td>' +
        '<td>' + faNum(Math.round(planned / 60)) + ' / ' + faNum(Math.round(need / 60)) + ' ساعت</td>' +
        '<td>' + faNum(testsDone) + ' / ' + faNum(testsNeed) + '</td>' +
        '<td>' + faNum(mastery) + '٪</td>' +
        '<td>' + faNum(reviews) + '</td>' +
        '<td>' + progressBar(planned / Math.max(1, need) * 100) + '</td></tr>';
    }).filter(Boolean);
    $('bookTable').innerHTML =
      '<table class="chap"><thead><tr><th>کتاب</th><th>فصل</th><th>پوشش</th><th>زمان چیده‌شده / لازم</th>' +
      '<th>تست انجام‌شده / لازم</th><th>تسلط فعلی</th><th>مرور</th><th style="width:120px">پیشرفت</th></tr></thead><tbody>' +
      rows.join('') + '</tbody></table>';
  }

  /** «چه چیزی مانده» — جملهٔ دقیق و قابل‌اجرا برای هر فصل */
  function remainingText(c) {
    if (c.mode === 'solid') return 'مرور فاصله‌دار تا کنکور';
    if (c.plannedMinutes === 0) {
      return c.read
        ? 'جبران نشده — نیازمند ' + faNum(c.needMinutes) + ' دقیقه بازآموزی'
        : 'هنوز خوانده نشده — نیازمند ' + faNum(c.needMinutes) + ' دقیقه';
    }
    if (c.covered) return c.testsNeed > 0 ? faNum(Math.max(0, c.testsNeed - c.testsDone)) + ' تست برای تکمیل' : 'تثبیت‌شده';
    const parts = [];
    if (c.remainingMinutes > 0) parts.push(faNum(c.remainingMinutes) + ' دقیقه مطالعه');
    if (c.testsNeed > c.testsDone) parts.push(faNum(c.testsNeed - c.testsDone) + ' تست');
    if (c.mastery < 75) parts.push('تسلط زیر ۷۵٪ (اکنون ' + faNum(Math.round(c.mastery)) + '٪)');
    return parts.length ? parts.join(' · ') : 'مرور';
  }

  function renderChapterTable(plan) {
    const box = $('chapterTable');
    if (!box) return;
    plan = plan || state.plan;
    if (!plan) return;
    const all = plan.summary.chapterStats || [];
    const book = ($('reportBook') && $('reportBook').value) || 'all';
    const filter = ($('reportFilter') && $('reportFilter').value) || 'all';
    let list = all.filter((c) => book === 'all' || c.subjectId === book);
    if (filter === 'open') list = list.filter((c) => !c.covered);
    else if (filter === 'weak') list = list.filter((c) => c.read && c.mastery < 75);
    else if (filter === 'deadline') list = list.filter((c) => c.deadlineIdx != null);
    else if (filter === 'week') {
      const today = iso(new Date());
      const weekEnd = (function () { const d = new Date(); d.setDate(d.getDate() + 7); return iso(d); })();
      const inWeek = new Set();
      state.plan.days.forEach((d) => {
        if (d.date >= today && d.date <= weekEnd) {
          d.blocks.forEach((b) => inWeek.add(b.subjectId + '|' + b.topic));
        }
      });
      list = list.filter((c) => Array.from(inWeek).some((k) => k.indexOf(c.subjectName + '|') === 0 && k.indexOf(c.label) !== -1));
    }

    if (!list.length) { box.innerHTML = '<div class="muted" style="font-size:12px">موردی با این فیلتر نیست.</div>'; return; }
    box.innerHTML =
      '<table class="chap"><thead><tr><th>فصل</th><th>وضعیت</th><th>تسلط</th><th>تست</th>' +
      '<th style="width:110px">پیشرفت</th><th>چه چیزی مانده</th></tr></thead><tbody>' +
      list.map((c) => '<tr' + (c.mode === 'solid' ? ' style="opacity:.75"' : '') + '>' +
        '<td><b style="font-size:12px">' + esc(c.label) + '</b>' +
          '<div class="muted" style="font-size:10.5px">' + esc(c.subjectName) +
          (c.deadlineTitle ? ' · مهلت: ' + esc(c.deadlineTitle) : '') + '</div></td>' +
        '<td><span class="pill ' + (c.mode === 'solid' ? '' : c.mastery < 45 ? 'hot' : c.mastery < 75 ? 'warm' : '') + '">' +
          esc(c.status) + '</span></td>' +
        '<td>' + faNum(Math.round(c.mastery)) + '٪<div class="muted" style="font-size:10.5px">هدف ۷۵٪</div></td>' +
        '<td><span dir="rtl">' + faNum(c.testsDone) + ' از ' + faNum(c.testsNeed) + '</span></td>' +
        '<td>' + progressBar(c.progress) + '</td>' +
        '<td style="font-size:11.5px">' + esc(remainingText(c)) + '</td>' +
      '</tr>').join('') + '</tbody></table>';
  }

  $('reportFilter').addEventListener('change', () => renderChapterTable(state.plan));
  $('reportBook').addEventListener('change', () => renderChapterTable(state.plan));

  /* ---------------- کارت مشاور: آمادگی و نقشهٔ جبران ---------------- */

  const MODE_FA = {
    learn: 'یادگیری از صفر',
    reteach: 'جبران و بازآموزی',
    boost: 'ارتقای تسلط',
    solid: 'فقط مرور',
  };

  function renderCoach(plan) {
    const c = (plan.summary && plan.summary.coverage) || null;
    if (!c) return;
    $('coachStats').innerHTML = [
      stat(faNum(c.readiness) + '٪', 'آمادگی فعلی'),
      stat(faNum(c.projectedReadiness) + '٪', 'برآورد پایان دوره'),
      stat(faNum(c.readChapters) + ' / ' + faNum(c.totalChapters), 'فصل خوانده‌شده'),
      stat(faNum(c.reteachChapters + c.boostChapters), 'فصل نیازمند جبران/ارتقا'),
    ].join('');

    const verdict = $('coachVerdict');
    verdict.innerHTML =
      '<div class="' + (c.willCover ? 'hint' : 'warn') + '">' +
        (c.willCover ? '✓ ' : '⚠ ') + esc(c.verdict) +
        ' <span class="muted" style="font-size:11px">(نیاز باقی‌مانده: ' + faNum(Math.round(c.remainingMinutes / 60)) +
        ' ساعت · ظرفیت آزاد تا کنکور: ' + faNum(Math.round(c.spareMinutes / 60)) + ' ساعت)</span>' +
      '</div>';

    const weak = (plan.summary.weakChapters || []).slice(0, 10);
    $('weakList').innerHTML = weak.length
      ? weak.map((w) => {
        const subj = (plan.summary.bySubject || []).find((x) => x.id === w.subjectId) || { weight: 1 };
        const cls = w.mastery < 45 ? 'hot' : 'warm';
        return '<div class="weakrow">' +
          '<span class="pill ' + cls + '">' + faNum(w.mastery) + '٪</span>' +
          '<b style="font-size:12px">' + esc(w.subjectName) + '</b>' +
          '<span style="flex:1">' + esc(w.label) + '</span>' +
          '<span class="muted" style="font-size:11px">' + esc(MODE_FA[w.mode] || w.mode) +
            ' · ضریب ' + faNum(subj.weight) + '</span>' +
          '<span class="muted" style="font-size:11px;min-width:78px;text-align:left">' +
            faNum(w.plannedMinutes) + ' دقیقه در برنامه</span>' +
        '</div>';
      }).join('')
      : '<div class="muted" style="font-size:12px">هیچ فصلی زیر ۷۵٪ تسلط نیست — وضعیت خوبی است؛ مرور فاصله‌دار ادامه پیدا می‌کند.</div>';

    const pr = plan.summary.priorities || [];
    $('priorityList').innerHTML = pr.length
      ? pr.map((x) => '<li>' + esc(x.subject) + ' — ' + esc(x.chapter) + ' <span class="pill ' +
          (x.mode === 'reteach' ? 'hot' : x.mode === 'boost' ? 'warm' : '') + '">' + esc(MODE_FA[x.mode] || x.mode) + '</span></li>').join('')
      : '<li class="muted">همهٔ فصل‌ها در وضعیت خوب‌اند؛ اولویت، حفظ تسلط با مرور و آزمون است.</li>';
  }

  function stat(value, label) {
    return '<div class="stat"><b>' + value + '</b><span>' + label + '</span></div>';
  }

  function renderWeek() {
    const plan = state.plan;
    const totalWeeks = Math.ceil(plan.days.length / 7);
    state.week = Math.max(0, Math.min(totalWeeks - 1, state.week));
    $('weekLabel').textContent = 'هفتهٔ ' + faNum(state.week + 1) + ' از ' + faNum(totalWeeks);

    const startIdx = state.week * 7;
    const pills = [];
    for (let i = startIdx; i < Math.min(startIdx + 7, plan.days.length); i++) {
      const d = plan.days[i];
      pills.push('<button class="day-pill' + (String(i) === String(state.selectedDay) ? ' active' : '') + '" data-day="' + i + '">' +
        esc(d.weekday) + '<small class="xp-day">' + jDayMonth(d.date) + '</small>' +
        '<small>' + faNum(Math.round(d.plannedMinutes / 60 * 10) / 10) + ' ساعت</small></button>');
    }
    $('dayPills').innerHTML = pills.join('');
    $('dayPills').querySelectorAll('[data-day]').forEach((b) => {
      b.addEventListener('click', () => { state.selectedDay = Number(b.dataset.day); renderWeek(); });
    });

    if (state.selectedDay == null || Math.floor(state.selectedDay / 7) !== state.week) {
      // پیش‌فرض: اولین روزِ پرِ همان هفته
      const first = plan.days.slice(startIdx, startIdx + 7).findIndex((d) => d.blocks.length);
      state.selectedDay = startIdx + (first === -1 ? 0 : first);
    }
    renderDay(state.selectedDay);
  }

  function renderDay(idx) {
    const plan = state.plan;
    const d = plan.days[idx];
    if (!d) { $('dayView').innerHTML = ''; return; }

    const head = '<div class="card" style="margin-bottom:10px;background:var(--panel2)">' +
      '<div class="row" style="justify-content:space-between">' +
      '<div><b style="font-size:13.5px">' + esc(jDateFull(d.date)) + '</b>' +
      '<div class="muted" style="font-size:11.5px;margin-top:3px">' + faNum(d.plannedMinutes) + ' دقیقه' +
      (d.isMockDay ? ' · آزمون جامع' : '') + (d.isDeload ? ' · هفتهٔ سبک' : '') + '</div></div>' +
      '</div>' + (d.note ? '<div class="muted" style="margin-top:8px">' + esc(d.note) + '</div>' : '') + '</div>';

    const events = (d.events || []).map((e) =>
      '<div class="evt' + (e.type === 'exam' ? ' exam' : '') + '">' +
      '<span>' + (e.type === 'exam' ? '📝' : '📌') + '</span>' +
      '<b>' + esc(e.title) + '</b>' +
      (e.subjectName ? '<span class="muted">· ' + esc(e.subjectName) + '</span>' : '') +
      '<span class="t">' + bidi(faNum(e.start) + '–' + faNum(e.end)) + (e.type === 'exam' ? ' · آزمون' : ' · کلاس') + '</span>' +
      '</div>').join('');

    const blocks = d.blocks.map((b, i) => {
      const key = d.date + '#' + i;
      const done = state.done[key] ? 'checked' : '';
      return '<div class="block">' +
        '<div class="time">' + bidi(faNum(b.start) + '–' + faNum(b.end)) + '<small>' + faNum(b.minutes) + ' دقیقه</small></div>' +
        '<div><div class="t">' + esc(b.subjectName) + ' <span class="muted" style="font-size:11px">· ' + esc(b.topic) + '</span></div>' +
        '<div class="c">' + esc(faNum(b.content)) + (b.retrievalTail ? ' <b style="color:#4f46e5">+' + faNum(b.retrievalTail) + ' دقیقه بازیابی</b>' : '') + '</div>' +
        '<div class="tech">' + esc(faNum(b.technique)) + '</div>' +
        (b.ifThen ? '<details><summary>جملهٔ اجرا (if-then)</summary>' + esc(b.ifThen) + '</details>' : '') +
        (b.why ? '<details><summary>چرا این کار؟</summary>' + esc(b.why) + '</details>' : '') +
        '</div>' +
        '<div><span class="badge ' + (KIND_CLASS[b.kind] || '') + '">' + esc(b.kindLabel) + '</span>' +
        '<div class="chk" style="margin-top:8px"><input type="checkbox" data-done="' + key + '" ' + done + ' /> انجام شد</div></div>' +
        '</div>';
    }).join('');

    const body = events + blocks;
    $('dayView').innerHTML = head + (body || '<div class="empty">این روز خالی است (استراحت).</div>');
    $('dayView').querySelectorAll('[data-done]').forEach((chk) => {
      chk.addEventListener('change', () => {
        state.done[chk.dataset.done] = chk.checked;
        persist();
      });
    });
  }

  $('prevWeek').addEventListener('click', () => { state.week--; state.selectedDay = null; renderWeek(); });
  $('nextWeek').addEventListener('click', () => { state.week++; state.selectedDay = null; renderWeek(); });
  /* «امروز»: هفته و روز جاری را پیدا و انتخاب می‌کند */
  if ($('todayBtn')) $('todayBtn').addEventListener('click', () => {
    const plan = state.plan;
    if (!plan || !plan.days || !plan.days.length) return;
    const todayISO = J ? J.dateToISO(new Date()) : iso(new Date());
    let idx = plan.days.findIndex((d) => d.date >= todayISO);
    if (idx < 0) idx = plan.days.length - 1;
    state.week = Math.floor(idx / 7);
    state.selectedDay = idx;
    renderWeek();
    toast('رفتی روی ' + (plan.days[idx] ? plan.days[idx].weekday : '') + ' ' + (plan.days[idx] && J ? J.fmt(plan.days[idx].date) : ''));
  });

  /* ---------------- ثبت درصد آزمون ---------------- */

  function renderScoreGrid() {
    const plan = state.plan;
    if (!plan) return;
    $('scoreGrid').innerHTML = plan.summary.bySubject.map((s) =>
      '<div><label>' + esc(s.name) + ' (تسلط فعلی ' + faNum(s.mastery) + '٪)</label>' +
      '<input type="number" min="-33" max="100" placeholder="درصد" data-score="' + esc(s.id) + '" value="' +
      (state.scores[s.id] == null ? '' : state.scores[s.id]) + '" /></div>'
    ).join('');
    $('scoreGrid').querySelectorAll('[data-score]').forEach((inp) => {
      inp.addEventListener('input', () => { state.scores[inp.dataset.score] = inp.value; });
    });
  }

  /* درصد آزمون هر درس را به ارزیابی فصل‌به‌فصل همان درس منتقل می‌کند
     (فصل‌های خوانده‌شده نصفِ فاصله به‌سمت درصد آزمون حرکت می‌کنند) */
  function syncScoresToChapters() {
    Object.keys(state.scores).forEach((sid) => {
      const v = state.scores[sid];
      if (v === undefined || v === '' || v === null) return;
      const rows = state.chapters[sid];
      if (!rows || !rows.length) return;
      const target = Math.max(0, Math.min(100, Number(v)));
      rows.forEach((r) => {
        if (!r.read) return;
        r.mastery = Math.round(Math.max(0, Math.min(100, r.mastery + 0.5 * (target - r.mastery))));
      });
    });
  }

  $('replan').addEventListener('click', () => {
    if (!state.plan) return;
    const cfg = JSON.parse(JSON.stringify(state.config));
    let changed = 0;
    cfg.subjects = cfg.subjects.map((s) => {
      const v = state.scores[s.id];
      if (v === undefined || v === '') return s;
      changed++;
      return engine.applySubjectScore ? engine.applySubjectScore(s, Number(v)) : engine.updateMastery(s, Number(v));
    });
    if (!changed) return toast('اول درصد آزمون حداقل یک درس را وارد کن.');
    // تاریخ شروع = امروز
    cfg.startDate = iso(new Date());
    // ارزیابی فصل‌ها هم با درصد آزمون به‌روز شود تا برنامهٔ جبران دقیق بماند
    syncScoresToChapters();
    cfg.subjects = cfg.subjects.map(withChapters);
    try {
      state.plan = engine.createPlan(cfg);
      state.config = cfg;
      state.week = 0;
      state.selectedDay = null;
      applyConfigToForm(cfg);
      renderPlan();
      persist();
      toast('برنامه با نتایج جدید بازتنظیم شد ✓');
    } catch (err) {
      toast('خطا: ' + err.message);
    }
  });

  /* ---------------- بازچینش هوشمند روزهای ازدست‌رفته ---------------- */

  function missedBlocks() {
    const plan = state.plan;
    if (!plan) return [];
    const today = iso(new Date());
    const out = [];
    plan.days.forEach((d) => {
      if (d.date >= today) return;
      d.blocks.forEach((b, bi) => {
        if (b.kind === 'exam' || b.kind === 'mock') return;      // آزمون برگزارشده قابل جبران نیست
        const key = d.date + '#' + bi;
        if (state.done[key]) return;
        out.push({ day: d.date, block: b, key });
      });
    });
    return out;
  }

  $('smartReplan').addEventListener('click', () => {
    if (!state.plan) return toast('اول برنامه را بساز.');
    const missed = missedBlocks();
    if (!missed.length) {
      state.lastCarry = [];
      $('carryCount').textContent = 'کار جامانده‌ای نیست — عالی پیش رفته‌ای.';
      return toast('چیزی برای جبران نیست.');
    }
    /* کارهای جامانده را به «کار عقب‌افتاده» تبدیل کن (فقط بخش یادگیری/تست، با سقف) */
    const byTopic = {};
    missed.forEach((m) => {
      if (m.block.kind === 'analysis' || m.block.kind === 'warmup') return;
      const k = m.block.subjectId + '|' + m.block.topic;
      byTopic[k] = byTopic[k] || {
        subjectId: m.block.subjectId, subjectName: m.block.subjectName,
        label: m.block.topic || m.block.kindLabel, minutes: 0,
        kind: (m.block.kind === 'review' || m.block.kind === 'cumreview') ? 'review' : 'learn',
      };
      byTopic[k].minutes += m.block.minutes;
    });
    const carry = Object.keys(byTopic).map((k) => byTopic[k]);
    if (!carry.length) {
      $('carryCount').textContent = 'جاماندهٔ قابل‌جبران نداشتی.';
      return toast('جاماندهٔ قابل‌جبران نبود.');
    }
    const cfg = JSON.parse(JSON.stringify(state.config || collectConfig()));
    cfg.startDate = iso(new Date());                 // از امروز به بعد بازچینش
    cfg.carryOver = carry;
    try {
      state.plan = engine.createPlan(cfg);
      state.config = cfg;
      state.week = 0;
      state.selectedDay = null;
      state.lastCarry = carry;
      $('carryCount').textContent = faNum(carry.length) + ' کار جامانده به روزهای آینده منتقل شد (' +
        faNum(Math.round(carry.reduce((a, c) => a + c.minutes, 0) / 60 * 10) / 10) + ' ساعت).';
      renderPlan();
      renderReport();
      persist();
      toast('بازچینش انجام شد ✓');
    } catch (err) { toast('خطا در بازچینش: ' + err.message); }
  });

  $('markTodayDone').addEventListener('click', () => {
    if (!state.plan) return toast('اول برنامه را بساز.');
    const today = iso(new Date());
    const d = state.plan.days.find((x) => x.date === today);
    if (!d) return toast('امروز در برنامه نیست.');
    let n = 0;
    d.blocks.forEach((b, bi) => { state.done[today + '#' + bi] = true; n += 1; });
    persist();
    toast(faNum(n) + ' بلوک امروز تیک خورد.');
  });

  /* ---------------- خروجی‌ها ---------------- */

  document.querySelectorAll('[data-export]').forEach((btn) => {
    btn.addEventListener('click', async () => {
      if (!state.plan) return toast('اول برنامه را بساز.');
      const type = btn.dataset.export;
      try {
        if (type === 'tasks') {
          const today = iso(new Date());
          const text = engine.toTaskList(state.plan, today) || engine.toTaskList(state.plan);
          await navigator.clipboard.writeText(text);
          return toast('تسک‌های امروز کپی شد — در روال بچسبان.');
        }
        if (type === 'report-md') {
          const content = buildReportMarkdown();
          if (api && api.saveFile) {
            const res = await api.saveFile({ name: 'گزارش-روال.md', ext: 'md', content });
            return toast(res && res.ok ? 'ذخیره شد: ' + res.path : 'ذخیره لغو شد.');
          }
          const a = document.createElement('a');
          a.href = URL.createObjectURL(new Blob([content], { type: 'text/markdown;charset=utf-8' }));
          a.download = 'گزارش-روال.md';
          a.click();
          return toast('گزارش ذخیره شد.');
        }
        if (type === 'report-csv') {
          const rows = [['کتاب', 'فصل', 'وضعیت', 'تسلط', 'تست انجام‌شده', 'تست لازم', 'پیشرفت', 'باقی‌مانده (دقیقه)']];
          (state.plan.summary.chapterStats || []).forEach((c) => rows.push([
            c.subjectName, c.label, c.status, c.mastery, c.testsDone, c.testsNeed, c.progress, c.remainingMinutes,
          ]));
          const csv = '\ufeff' + rows.map((r) => r.map((x) => '"' + String(x).replace(/"/g, '""') + '"').join(',')).join('\r\n');
          const a = document.createElement('a');
          a.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8' }));
          a.download = 'گزارش-فصل‌ها.csv';
          a.click();
          return toast('گزارش فصل‌ها ذخیره شد.');
        }
        const map = {
          md: { content: engine.toMarkdown(state.plan), ext: 'md', label: 'برنامه-روال.md' },
          csv: { content: '\ufeff' + engine.toCSV(state.plan), ext: 'csv', label: 'برنامه-روال.csv' },
          ics: { content: engine.toICS(state.plan), ext: 'ics', label: 'برنامه-روال.ics' },
          json: { content: JSON.stringify({ config: state.config, plan: state.plan }, null, 2), ext: 'json', label: 'برنامه-روال.json' },
        };
        const f = map[type];
        if (api && api.saveFile) {
          const res = await api.saveFile({ name: f.label, ext: f.ext, content: f.content });
          toast(res && res.ok ? 'ذخیره شد: ' + res.path : 'ذخیره لغو شد.');
        } else {
          const blob = new Blob([f.content], { type: 'text/plain;charset=utf-8' });
          const a = document.createElement('a');
          a.href = URL.createObjectURL(blob);
          a.download = f.label;
          a.click();
          toast('دانلود شد.');
        }
      } catch (err) {
        toast('خطا در خروجی: ' + err.message);
      }
    });
  });

  function buildReportMarkdown() {
    const plan = state.plan;
    const c = plan.summary.coverage;
    const L = [];
    L.push('# گزارش برنامهٔ روال — ' + (plan.meta.studentName || ''));
    L.push('');
    L.push('- پوشش فصل‌ها: **' + faNum(c.coverageRatio) + '٪**');
    L.push('- آمادگی کنکور: ' + faNum(c.readiness) + '٪ → برآورد پایان: **' + faNum(c.projectedReadiness) + '٪**');
    L.push('- آمادگی سوابق تحصیلی: **' + faNum(c.finalsReadiness) + '٪** · نمرهٔ ترکیبی ۱۴۰۶: **' + faNum(c.composite) + '٪**');
    L.push('- ساعت برنامه‌ریزی‌شده: ' + faNum(plan.summary.totalHours) + ' ساعت · تست: ' + faNum(c.testsPlanned) +
      ' (' + faNum(c.testsPerDay) + ' در روز)');
    L.push('');
    if ((c.deadlines || []).length) {
      L.push('## مهلت‌ها');
      L.push('| مهلت | مدل | تاریخ | وضعیت | زمان چیده‌شده / لازم |');
      L.push('|---|---|---|---|---|');
      c.deadlines.forEach((d) => L.push('| ' + d.title + ' | ' + (d.model === 'book' ? 'کتابی' : 'آزمون') +
        ' | ' + faNum(J ? J.fmt(d.date) : d.date) + ' | ' + (DL_STATUS[d.status] || {}).fa +
        ' | ' + Math.round(d.plannedMinutes / 60) + ' / ' + Math.round(d.needMinutes / 60) + ' ساعت |'));
      L.push('');
    }
    if ((c.finalsCourses || []).length) {
      L.push('## سوابق تحصیلی (نهایی)');
      L.push('| درس | ضریب | فعلی | هدف | برآورد پایان | زمان چیده‌شده / لازم |');
      L.push('|---|---|---|---|---|---|');
      c.finalsCourses.forEach((x) => L.push('| ' + x.name + ' | ' + x.influence + ' | ' +
        (Math.round(x.current * 10) / 10) + (x.assumed ? ' (فرض)' : '') + ' | ' + x.target + ' | ' +
        (Math.round((x.projected / 100) * 20 * 10) / 10) + ' | ' +
        Math.round(x.plannedMinutes / 60 * 10) / 10 + ' / ' + Math.round(x.needMinutes / 60 * 10) / 10 + ' |'));
      L.push('');
    }
    L.push('## فصل‌به‌فصل');
    L.push('| کتاب | فصل | وضعیت | تسلط | تست | پیشرفت | چه چیزی مانده |');
    L.push('|---|---|---|---|---|---|---|');
    (plan.summary.chapterStats || []).forEach((x) => L.push('| ' + x.subjectName + ' | ' + x.label + ' | ' + x.status +
      ' | ' + Math.round(x.mastery) + '٪ | ' + x.testsDone + '/' + x.testsNeed + ' | ' + x.progress + '٪ | ' + remainingText(x) + ' |'));
    return L.join('\n');
  }

  /* ---------------- ذخیره/بازیابی ---------------- */

  async function persist() {
    if (!api || !api.saveState) return;
    try {
      await api.saveState({
        config: state.config,
        plan: state.plan,
        scores: state.scores,
        done: state.done,
        visited: state.visited,
      });
    } catch (e) { /* بی‌صدا */ }
  }

  async function restore() {
    if (api && api.loadState) {
      try {
        const data = await api.loadState();
        if (data && data.config) {
          applyConfigToForm(data.config);
          state.scores = data.scores || {};
          state.done = data.done || {};
          state.visited = data.visited || {};
          if (data.plan) {
            state.plan = data.plan;
            renderPlan();
            return;
          }
          return;
        }
      } catch (e) { /* ادامه با پیش‌فرض */ }
    }
    applyConfigToForm(defaultConfig());
  }

  /* ---------------- به‌روزرسانی خودکار ---------------- */

  const upd = (api && api.updates) ? api.updates : null;
  let updateSnap = null;
  let userDismissed = false;

  /* شمارهٔ نسخه با رقم فارسی ولی نقطه‌های استاندارد نسخه (۲.۲.۰ نه ۲٫۲٫۰) */
  function upVer(v) { return String(v == null ? '—' : v).replace(/\d/g, (d) => '۰۱۲۳۴۵۶۷۸۹'[d]); }
  function upFa(n) { return faNum(String(n)); }

  function renderUpdate(snap, opts) {
    if (!snap) return;
    updateSnap = snap;
    const bar = $('updateBar');
    const chip = $('verChip');
    const txt = $('verText');
    if (txt) txt.textContent = upVer(snap.current || '—');
    if (chip) chip.classList.toggle('has', Boolean(snap.hasUpdate));
    if (!bar) return;

    const title = $('ubarTitle');
    const sub = $('ubarSub');
    const act = $('ubarAction');
    const fullBtn0 = $('ubarFull');
    if (fullBtn0) fullBtn0.addEventListener('click', async () => {
      try {
        renderUpdate({ ...(updateSnap || {}), status: 'checking' }, { manual: false });
        const snap = await upd.now({ full: true });
        renderUpdate(snap || updateSnap, { manual: true });
      } catch (e) {
        renderUpdate({ ...(updateSnap || {}), status: 'error', error: 'دانلود کامل انجام نشد' }, { manual: true });
      }
    });
    const later = $('ubarLater');
    const prog = $('ubarProg');
    const fill = $('ubarFill');
    const fullBtn = $('ubarFull');
    bar.classList.remove('err', 'done');
    /* هر رندر از صفر: وگرنه حالت پنهانِ رندر قبلی به ارث می‌رسد (باگ «دکمه‌ای نمی‌بینم») */
    act.hidden = false;
    act.disabled = false;
    later.hidden = false;
    prog.hidden = true;
    if (fullBtn) fullBtn.hidden = true;
    const show = (kind) => { if (!(userDismissed && kind !== 'ready' && kind !== 'downloading')) bar.hidden = false; };

    const sizeMb = snap.sizeMb ? upFa(snap.sizeMb) + ' مگابایت' : '';
    const patchKb = snap.patchKb ? upFa(snap.patchKb) + ' کیلوبایت' : '';

    if (snap.status === 'downloading') {
      show('downloading');
      bar.classList.add('done');
      prog.hidden = false;
      fill.style.width = Math.max(2, snap.percent || 0) + '%';
      title.textContent = 'در حال دانلود نسخهٔ ' + upVer(snap.latest) + '…';
      sub.textContent = upFa(Math.round(snap.percent || 0)) + '٪ — ' +
        upFa(snap.receivedMb) + ' از ' + upFa(snap.totalMb || snap.sizeMb || 0) + ' مگابایت. دانلود متوقف نشود.';
      act.textContent = 'در حال دانلود…';
      act.disabled = true;
      later.hidden = true;
      return;
    }

    if (snap.status === 'ready') {
      show('ready');
      bar.classList.add('done');
      prog.hidden = false;
      fill.style.width = '100%';
      title.textContent = 'نسخهٔ ' + upVer(snap.latest) + ' دانلود شد ✅';
      sub.textContent = snap.usedPatch
        ? 'فقط کدِ تغییریافته دانلود شد' +
          (snap.savedMb ? ' (' + upFa(snap.savedMb) + ' مگابایت صرفه‌جویی)' : '') +
          ' — برای نصب، برنامه بسته و خودکار دوباره باز می‌شود. داده‌هایت حفظ می‌شود.'
        : 'برای نصب، برنامه بسته و خودکار دوباره باز می‌شود. برنامه‌ها، تیک‌ها و درصدهای تو حفظ می‌شوند.';
      act.textContent = 'نصب و راه‌اندازی مجدد';
      act.disabled = false;
      later.hidden = false;
      later.textContent = 'بستن';
      return;
    }

    later.hidden = false;
    later.textContent = 'بعداً';
    prog.hidden = true;
    act.disabled = false;

    if (snap.status === 'installing') {
      show('installing');
      title.textContent = 'در حال نصب نسخهٔ ' + upVer(snap.latest) + '…';
      sub.textContent = 'برنامه بسته می‌شود و نسخهٔ تازه باز می‌شود.';
      act.textContent = 'در حال نصب…';
      act.disabled = true;
      later.hidden = true;
      return;
    }

    if (snap.hasUpdate && snap.latest) {
      show('available');
      const usePatch = snap.patchAvailable && patchKb;
      title.textContent = 'نسخهٔ جدید موجود است: ' + upVer(snap.latest);
      sub.textContent = 'نسخهٔ فعلی ' + upVer(snap.current) +
        (usePatch
          ? ' — فقط بخش‌های تغییریافته دانلود می‌شود (' + patchKb + (sizeMb ? ' · به‌جای ' + sizeMb : '') + '). با یک کلیک نصب و برنامه دوباره باز می‌شود.'
          : (sizeMb ? ' · ' + sizeMb : '') + ' — با یک کلیک دانلود و نصب می‌شود.');
      act.textContent = usePatch ? 'به‌روزرسانی سریع (' + patchKb + ')' : 'به‌روزرسانی';
      if (fullBtn) fullBtn.hidden = !snap.patchAvailable;
      return;
    }

    if (snap.status === 'latest') {
      if (opts && opts.manual) {
        show('latest');
        bar.classList.add('done');
        title.textContent = 'شما آخرین نسخه را دارید ✅';
        sub.textContent = 'نسخهٔ ' + upVer(snap.current) + ' · بررسی شد در ' + upFa(clockNow());
        act.hidden = true;
        later.textContent = 'باشه';
        setTimeout(() => { if (!userDismissed) bar.hidden = true; }, 7000);
      } else {
        bar.hidden = true;
      }
      return;
    }

    if (snap.status === 'error') {
      if (opts && opts.manual) {
        show('error');
        bar.classList.add('err');
        title.textContent = 'بررسی به‌روزرسانی انجام نشد';
        sub.textContent = snap.error || 'اتصال اینترنت را بررسی کن.';
        act.textContent = 'تلاش دوباره';
        act.hidden = false;
      } else {
        bar.hidden = true; /* بررسی خودکارِ ناموفق، کاربر را آزار نمی‌دهد */
      }
      return;
    }

    if (snap.status === 'checking') {
      show('checking');
      title.textContent = 'در حال بررسی نسخهٔ جدید…';
      sub.textContent = 'اتصال به گیت‌هاب';
      prog.hidden = true;
      act.textContent = 'بررسی…';
      act.disabled = true;
      return;
    }

    act.hidden = false;
    if (snap.hasUpdate) show('available');
    else bar.hidden = true;
  }

  function clockNow() {
    const d = new Date();
    return pad(d.getHours()) + ':' + pad(d.getMinutes());
  }

  function initUpdates() {
    if (!upd) return;
    if (upd.onEvent) {
      upd.onEvent((ev) => {
        if (!ev || !ev.state) return;
        renderUpdate(ev.state, { manual: ev.type !== 'state' || ev.state.status !== 'checking' });
      });
    }
    if (upd.state) {
      upd.state().then((snap) => renderUpdate(snap, { manual: false })).catch(() => {});
    }
    const chip = $('verChip');
    if (chip) chip.addEventListener('click', () => {
      userDismissed = false;
      const bar = $('updateBar');
      if (bar) bar.hidden = false;
      renderUpdate({ ...(updateSnap || {}), status: 'checking' }, { manual: true });
      if (upd.check) upd.check().then((snap) => renderUpdate(snap, { manual: true })).catch(() => {});
    });
    const act = $('ubarAction');
    if (act) act.addEventListener('click', async () => {
      const s = updateSnap || {};
      try {
        if (s.status === 'ready') { act.disabled = true; await upd.install(); return; }
        if (s.status === 'error' || !s.hasUpdate) {
          renderUpdate({ ...s, status: 'checking' }, { manual: true });
          const snap = await upd.check();
          renderUpdate(snap, { manual: true });
          if (snap && snap.hasUpdate) {
            const after = await upd.now(); /* دانلود + نصب در یک کلیک */
            renderUpdate(after, { manual: true });
          }
          return;
        }
        act.disabled = true;
        act.textContent = 'شروع دانلود…';
        const snap = await upd.now(); /* دانلود و سپس نصب خودکار */
        renderUpdate(snap, { manual: true });
        if (snap && snap.status === 'ready') { /* نصب در updateNow انجام شده */ }
      } catch (e) {
        renderUpdate({ ...(updateSnap || {}), status: 'error', error: 'خطای غیرمنتظره در به‌روزرسانی' }, { manual: true });
      }
    });
    const later = $('ubarLater');
    if (later) later.addEventListener('click', () => {
      userDismissed = true;
      const bar = $('updateBar');
      if (bar) bar.hidden = true;
    });
  }

  /* ورودی‌های عددی: رقم فارسی هم پذیرفته می‌شود (کیبورد فارسی) */
  document.addEventListener('input', (ev) => {
    const el = ev.target;
    if (!el || el.tagName !== 'INPUT') return;
    const numeric = el.type === 'number' || (el.classList && el.classList.contains('num'));
    if (!numeric) return;
    const conv = String(el.value).replace(/[۰-۹٠-٩]/g, (c) => EN_DIGITS[c] || c).replace(/٫/g, '.');
    if (conv !== el.value) {
      const pos = el.selectionStart;
      el.value = conv;
      try { el.setSelectionRange(pos, pos); } catch (e) { /* بی‌صدا */ }
    }
  }, true);

  /* ورودی ساعت: با خروج از فیلد، خودکار به شکل ۲۴ ساعتهٔ فارسی درمی‌آید */
  document.addEventListener('focusout', (ev) => {
    const el = ev.target;
    if (!el || !el.classList || !el.classList.contains('tin')) return;
    const t = normTime(el.value);
    if (t) { el.value = faDigits(t); el.classList.remove('bad'); }
    else if (String(el.value).trim()) el.classList.add('bad');
  }, true);
  /* Enter در ورودی ساعت: مقدار را نرمال کن و از فیلد بیرون بیا */
  document.addEventListener('keydown', (ev) => {
    const el = ev.target;
    if (!el || !el.classList || !el.classList.contains('tin')) return;
    if (ev.key === 'Enter') {
      const t = normTime(el.value);
      if (t) { el.value = faDigits(t); el.classList.remove('bad'); }
      el.blur();
      ev.preventDefault();
    }
  }, true);

  /* ---------------- شروع ---------------- */

  if (J) J.attachAll(document);
  initUpdates();
  try { installHelp(); } catch (e) { console.error(e); }
  [['modeFixed', 'fixed'], ['modeAuto', 'auto']].forEach(([id, mode]) => {
    const b = $(id);
    if (b) b.addEventListener('click', () => { setTimeMode(mode); try { persist(); } catch (e) { /* بی‌صدا */ } });
  });
  setTimeMode('fixed');
  restore().then(() => { try { renderHome(); } catch (e) { /* بی‌صدا */ } });

  /* با هر تغییر در فرم، نمای خانه و تیک‌های نوار کنار تازه می‌شوند */
  let homeTick = null;
  document.addEventListener('input', () => {
    clearTimeout(homeTick);
    homeTick = setTimeout(() => { if (window.__revalView === 'home' || !window.__revalView) renderHome(); else renderHome(); }, 250);
  }, true);
  document.addEventListener('change', () => { try { renderHome(); } catch (e) { /* بی‌صدا */ } }, true);
})();
